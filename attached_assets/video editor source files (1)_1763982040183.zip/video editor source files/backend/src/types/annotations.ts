export type AnnotationItem =
  | {
      type: 'arrow';
      at: number;
      props: {
        points: number[];
        stroke: string;
        width: number;
      };
    }
  | {
      type: 'circle';
      at: number;
      props: {
        x: number;
        y: number;
        r: number;
        stroke: string;
        width: number;
      };
    }
  | {
      type: 'freehand';
      at: number;
      props: {
        path: number[][];
        stroke: string;
        width: number;
      };
    };

export interface AnnotationComment {
  at: number;
  text: string;
}

export interface AnnotationPayload {
  videoId: string;
  framesPerSecond: number;
  items: AnnotationItem[];
  comments: AnnotationComment[];
}
