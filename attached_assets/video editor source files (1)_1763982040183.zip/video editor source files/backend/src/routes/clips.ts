import { Router } from 'express';
import { z } from 'zod';
import { authenticate, AuthRequest, requireRole } from '../auth/middleware.js';
import { db } from '../db/client.js';
import { jobQueue } from '../ffmpeg/jobs.js';
import { logger } from '../utils/logger.js';
import { unlink } from 'fs/promises';
import { join } from 'path';
import { existsSync } from 'fs';

const router = Router();

const createClipSchema = z.object({
  videoId: z.string().cuid(),
  startSeconds: z.number().min(0),
  endSeconds: z.number().min(0),
  comment: z.string().optional(),
});

router.post('/api/clips', authenticate, requireRole('COACH'), async (req: AuthRequest, res) => {
  try {
    const { videoId, startSeconds, endSeconds, comment } = createClipSchema.parse(req.body);

    if (endSeconds <= startSeconds) {
      res.status(400).json({ error: 'endSeconds must be greater than startSeconds' });
      return;
    }

    const video = await db.video.findUnique({ where: { id: videoId } });
    if (!video) {
      res.status(404).json({ error: 'Video not found' });
      return;
    }

    if (video.status !== 'READY') {
      res.status(400).json({ error: 'Video is not ready for clipping' });
      return;
    }

    const clip = await db.clip.create({
      data: {
        videoId,
        coachId: req.user!.userId,
        startSeconds,
        endSeconds,
        comment,
        status: 'QUEUED',
      },
    });

    jobQueue.enqueue('clip', { clipId: clip.id });

    logger.info('Clip created and queued', { clipId: clip.id, videoId });

    res.status(201).json(clip);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ error: 'Invalid request', details: error.errors });
      return;
    }

    logger.error('Create clip error', { error: (error as Error).message });
    res.status(500).json({ error: 'Failed to create clip' });
  }
});

router.get('/api/videos/:id/clips', authenticate, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    const video = await db.video.findUnique({ where: { id } });
    if (!video) {
      res.status(404).json({ error: 'Video not found' });
      return;
    }

    if (req.user!.role === 'STUDENT' && video.studentId !== req.user!.userId) {
      res.status(403).json({ error: 'Access denied' });
      return;
    }

    const clips = await db.clip.findMany({
      where: { videoId: id },
      include: {
        coach: { select: { id: true, email: true, role: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    res.json(clips);
  } catch (error) {
    logger.error('List clips error', { error: (error as Error).message });
    res.status(500).json({ error: 'Failed to list clips' });
  }
});

router.get('/api/clips/:id', authenticate, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    const clip = await db.clip.findUnique({
      where: { id },
      include: {
        video: { select: { id: true, studentId: true } },
        coach: { select: { id: true, email: true, role: true } },
      },
    });

    if (!clip) {
      res.status(404).json({ error: 'Clip not found' });
      return;
    }

    if (req.user!.role === 'STUDENT' && clip.video.studentId !== req.user!.userId) {
      res.status(403).json({ error: 'Access denied' });
      return;
    }

    res.json(clip);
  } catch (error) {
    logger.error('Get clip error', { error: (error as Error).message });
    res.status(500).json({ error: 'Failed to get clip' });
  }
});

router.delete('/api/clips/:id', authenticate, requireRole('COACH'), async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    const clip = await db.clip.findUnique({
      where: { id },
    });

    if (!clip) {
      res.status(404).json({ error: 'Clip not found' });
      return;
    }

    // Only the coach who created the clip can delete it
    if (clip.coachId !== req.user!.userId) {
      res.status(403).json({ error: 'You can only delete your own clips' });
      return;
    }

    const UPLOAD_DIR = join(process.cwd(), 'uploads');

    // Delete the clip file if it exists
    if (clip.outputStorageKey) {
      const clipPath = join(UPLOAD_DIR, clip.outputStorageKey);
      if (existsSync(clipPath)) {
        await unlink(clipPath).catch((err) =>
          logger.warn('Failed to delete clip file', { path: clipPath, error: err.message })
        );
      }
    }

    // Delete from database
    await db.clip.delete({ where: { id } });

    logger.info('Clip deleted', { clipId: id, coachId: req.user!.userId });

    res.json({ message: 'Clip deleted successfully' });
  } catch (error) {
    logger.error('Delete clip error', { error: (error as Error).message });
    res.status(500).json({ error: 'Failed to delete clip' });
  }
});

export default router;
