import { Router } from 'express';
import { writeFile, mkdir } from 'fs/promises';
import { join, dirname } from 'path';
import { existsSync } from 'fs';
import { authenticate, AuthRequest } from '../auth/middleware.js';
import { logger } from '../utils/logger.js';
import { uploadIdToStorageKey } from '../storage/local.js';

const router = Router();
const UPLOAD_DIR = join(process.cwd(), 'uploads');

async function ensureDir(dir: string): Promise<void> {
  if (!existsSync(dir)) {
    await mkdir(dir, { recursive: true });
  }
}

const pendingUploads = new Map<string, { userId: string; timestamp: number }>();

router.put('/api/upload/direct/:uploadId', authenticate, async (req: AuthRequest, res) => {
  try {
    const { uploadId } = req.params;
    const userId = req.user!.userId;

    pendingUploads.set(uploadId, { userId, timestamp: Date.now() });

    const chunks: Buffer[] = [];

    req.on('data', (chunk) => {
      chunks.push(chunk);
    });

    req.on('end', async () => {
      try {
        const buffer = Buffer.concat(chunks);

        const uploadInfo = pendingUploads.get(uploadId);
        if (!uploadInfo) {
          res.status(400).json({ error: 'Invalid upload ID' });
          return;
        }

        // Get the storage key from the presign mapping
        const storageKey = uploadIdToStorageKey.get(uploadId);
        if (!storageKey) {
          res.status(400).json({ error: 'Storage key not found for upload ID' });
          return;
        }

        const filePath = join(UPLOAD_DIR, storageKey);

        await ensureDir(dirname(filePath));
        await writeFile(filePath, buffer);

        pendingUploads.delete(uploadId);
        uploadIdToStorageKey.delete(uploadId);

        logger.info('Direct upload completed', { uploadId, storageKey, size: buffer.length });

        res.json({ success: true, storageKey });
      } catch (error) {
        logger.error('Direct upload processing error', { error: (error as Error).message });
        res.status(500).json({ error: 'Upload processing failed' });
      }
    });

    req.on('error', (error) => {
      logger.error('Direct upload stream error', { error: error.message });
      res.status(500).json({ error: 'Upload stream error' });
    });

  } catch (error) {
    logger.error('Direct upload error', { error: (error as Error).message });
    res.status(500).json({ error: 'Upload failed' });
  }
});

setInterval(() => {
  const now = Date.now();
  for (const [uploadId, info] of pendingUploads.entries()) {
    if (now - info.timestamp > 3600000) {
      pendingUploads.delete(uploadId);
    }
  }
}, 60000);

export default router;
