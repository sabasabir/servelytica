import { Router } from 'express';
import { z } from 'zod';
import { authenticate, AuthRequest, requireRole } from '../auth/middleware.js';
import { db } from '../db/client.js';
import { logger } from '../utils/logger.js';

const router = Router();

const annotationPayloadSchema = z.object({
  videoId: z.string(),
  framesPerSecond: z.number(),
  items: z.array(
    z.union([
      z.object({
        type: z.literal('arrow'),
        at: z.number(),
        props: z.object({
          points: z.array(z.number()),
          stroke: z.string(),
          width: z.number(),
        }),
      }),
      z.object({
        type: z.literal('circle'),
        at: z.number(),
        props: z.object({
          x: z.number(),
          y: z.number(),
          r: z.number(),
          stroke: z.string(),
          width: z.number(),
        }),
      }),
      z.object({
        type: z.literal('freehand'),
        at: z.number(),
        props: z.object({
          path: z.array(z.array(z.number())),
          stroke: z.string(),
          width: z.number(),
        }),
      }),
    ])
  ),
  comments: z.array(
    z.object({
      at: z.number(),
      text: z.string(),
    })
  ),
});

const createAnnotationSchema = z.object({
  videoId: z.string().cuid(),
  name: z.string().min(1),
  payload: annotationPayloadSchema,
});

router.post('/api/annotations', authenticate, requireRole('COACH'), async (req: AuthRequest, res) => {
  try {
    const { videoId, name, payload } = createAnnotationSchema.parse(req.body);

    const video = await db.video.findUnique({ where: { id: videoId } });
    if (!video) {
      res.status(404).json({ error: 'Video not found' });
      return;
    }

    const annotation = await db.annotation.create({
      data: {
        videoId,
        coachId: req.user!.userId,
        name,
        payload: payload as any,
      },
    });

    logger.info('Annotation created', { annotationId: annotation.id, videoId });

    res.status(201).json(annotation);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ error: 'Invalid request', details: error.errors });
      return;
    }

    logger.error('Create annotation error', { error: (error as Error).message });
    res.status(500).json({ error: 'Failed to create annotation' });
  }
});

router.get('/api/videos/:id/annotations', authenticate, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    const video = await db.video.findUnique({ where: { id } });
    if (!video) {
      res.status(404).json({ error: 'Video not found' });
      return;
    }

    if (req.user!.role === 'STUDENT' && video.studentId !== req.user!.userId) {
      res.status(403).json({ error: 'Access denied' });
      return;
    }

    const annotations = await db.annotation.findMany({
      where: { videoId: id },
      include: {
        coach: { select: { id: true, email: true, role: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    res.json(annotations);
  } catch (error) {
    logger.error('List annotations error', { error: (error as Error).message });
    res.status(500).json({ error: 'Failed to list annotations' });
  }
});

router.get('/api/annotations/:id', authenticate, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    const annotation = await db.annotation.findUnique({
      where: { id },
      include: {
        video: { select: { id: true, studentId: true } },
        coach: { select: { id: true, email: true, role: true } },
      },
    });

    if (!annotation) {
      res.status(404).json({ error: 'Annotation not found' });
      return;
    }

    if (req.user!.role === 'STUDENT' && annotation.video.studentId !== req.user!.userId) {
      res.status(403).json({ error: 'Access denied' });
      return;
    }

    res.json(annotation);
  } catch (error) {
    logger.error('Get annotation error', { error: (error as Error).message });
    res.status(500).json({ error: 'Failed to get annotation' });
  }
});

export default router;
