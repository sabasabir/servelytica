import { Router } from 'express';
import { createReadStream, existsSync } from 'fs';
import { join } from 'path';
import { stat } from 'fs/promises';
import { logger } from '../utils/logger.js';

const router = Router();
const UPLOAD_DIR = join(process.cwd(), 'uploads');

router.get('/api/files/*', async (req, res) => {
  try {
    const storageKey = req.params[0];
    const filePath = join(UPLOAD_DIR, storageKey);

    if (!existsSync(filePath)) {
      res.status(404).json({ error: 'File not found' });
      return;
    }

    const stats = await stat(filePath);
    const fileSize = stats.size;

    const range = req.headers.range;

    if (range) {
      const parts = range.replace(/bytes=/, '').split('-');
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
      const chunksize = end - start + 1;

      res.writeHead(206, {
        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunksize,
        'Content-Type': 'video/mp4',
      });

      createReadStream(filePath, { start, end }).pipe(res);
    } else {
      res.writeHead(200, {
        'Content-Length': fileSize,
        'Content-Type': 'video/mp4',
      });

      createReadStream(filePath).pipe(res);
    }
  } catch (error) {
    logger.error('File serve error', { error: (error as Error).message });
    res.status(500).json({ error: 'Failed to serve file' });
  }
});

export default router;
