import { Router } from 'express';
import { z } from 'zod';
import { authenticate, AuthRequest, requireRole } from '../auth/middleware.js';
import { db } from '../db/client.js';
import { burninAnnotations } from '../ffmpeg/burnin.js';
import { logger } from '../utils/logger.js';

const router = Router();

const renderSchema = z.object({
  videoId: z.string().cuid(),
  annotationId: z.string().cuid(),
});

const renderJobs = new Map<string, { status: string; url?: string; error?: string }>();

router.post('/api/render/annotated-video', authenticate, requireRole('COACH'), async (req: AuthRequest, res) => {
  try {
    const { videoId, annotationId } = renderSchema.parse(req.body);

    const video = await db.video.findUnique({ where: { id: videoId } });
    const annotation = await db.annotation.findUnique({ where: { id: annotationId } });

    if (!video || !annotation) {
      res.status(404).json({ error: 'Video or annotation not found' });
      return;
    }

    if (video.status !== 'READY') {
      res.status(400).json({ error: 'Video is not ready for rendering' });
      return;
    }

    const jobId = `render_${videoId}_${annotationId}_${Date.now()}`;
    renderJobs.set(jobId, { status: 'processing' });

    burninAnnotations({ videoId, annotationId })
      .then((url) => {
        renderJobs.set(jobId, { status: 'completed', url });
        logger.info('Render job completed', { jobId, url });
      })
      .catch((error) => {
        renderJobs.set(jobId, { status: 'failed', error: (error as Error).message });
        logger.error('Render job failed', { jobId, error: (error as Error).message });
      });

    res.status(202).json({ jobId, status: 'processing' });
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ error: 'Invalid request', details: error.errors });
      return;
    }

    logger.error('Render request error', { error: (error as Error).message });
    res.status(500).json({ error: 'Failed to start render job' });
  }
});

router.get('/api/render/jobs/:id', authenticate, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    const job = renderJobs.get(id);

    if (!job) {
      res.status(404).json({ error: 'Job not found' });
      return;
    }

    res.json({ jobId: id, ...job });
  } catch (error) {
    logger.error('Get render job error', { error: (error as Error).message });
    res.status(500).json({ error: 'Failed to get render job' });
  }
});

export default router;
