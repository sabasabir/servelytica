import { Router } from 'express';
import { z } from 'zod';
import { authenticate, AuthRequest } from '../auth/middleware.js';
import { generatePresignedUpload } from '../storage/index.js';
import { logger } from '../utils/logger.js';

const router = Router();

const presignSchema = z.object({
  filename: z.string().min(1),
  contentType: z.string().regex(/^video\/(mp4|avi|mov|quicktime|x-msvideo)$/),
});

router.post('/api/upload/presign', authenticate, async (req: AuthRequest, res) => {
  try {
    const { filename, contentType } = presignSchema.parse(req.body);

    const presignedData = await generatePresignedUpload(
      req.user!.userId,
      filename,
      contentType
    );

    res.json(presignedData);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ error: 'Invalid request', details: error.errors });
      return;
    }

    logger.error('Presign upload error', { error: (error as Error).message });
    res.status(500).json({ error: 'Failed to generate presigned URL' });
  }
});

export default router;
