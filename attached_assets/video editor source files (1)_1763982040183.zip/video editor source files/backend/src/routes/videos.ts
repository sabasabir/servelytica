import { Router } from 'express';
import { z } from 'zod';
import { authenticate, AuthRequest, requireRole } from '../auth/middleware.js';
import { db } from '../db/client.js';
import { jobQueue } from '../ffmpeg/jobs.js';
import { logger } from '../utils/logger.js';
import { unlink } from 'fs/promises';
import { join } from 'path';
import { existsSync } from 'fs';

const router = Router();

const createVideoSchema = z.object({
  studentId: z.string().cuid(),
  storageKey: z.string().min(1),
  playbackUrl: z.string().url(),
  originalName: z.string().optional(),
});

router.post('/api/videos', authenticate, async (req: AuthRequest, res) => {
  try {
    const { studentId, storageKey, playbackUrl, originalName } = createVideoSchema.parse(req.body);

    if (req.user!.role === 'STUDENT' && req.user!.userId !== studentId) {
      res.status(403).json({ error: 'Cannot create video for another student' });
      return;
    }

    const video = await db.video.create({
      data: {
        studentId,
        storageKey,
        playbackUrl,
        originalName,
        status: 'UPLOADED',
      },
    });

    jobQueue.enqueue('normalize', {
      videoId: video.id,
      inputStorageKey: storageKey,
    });

    logger.info('Video created and normalization queued', { videoId: video.id });

    res.status(201).json(video);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ error: 'Invalid request', details: error.errors });
      return;
    }

    logger.error('Create video error', { error: (error as Error).message });
    res.status(500).json({ error: 'Failed to create video' });
  }
});

router.get('/api/videos', authenticate, async (req: AuthRequest, res) => {
  try {
    const role = req.user!.role;
    const userId = req.user!.userId;

    let videos;

    if (role === 'STUDENT') {
      videos = await db.video.findMany({
        where: { studentId: userId },
        include: {
          student: { select: { id: true, email: true, role: true } },
          coach: { select: { id: true, email: true, role: true } },
        },
        orderBy: { createdAt: 'desc' },
      });
    } else {
      videos = await db.video.findMany({
        include: {
          student: { select: { id: true, email: true, role: true } },
          coach: { select: { id: true, email: true, role: true } },
        },
        orderBy: { createdAt: 'desc' },
      });
    }

    res.json(videos);
  } catch (error) {
    logger.error('List videos error', { error: (error as Error).message });
    res.status(500).json({ error: 'Failed to list videos' });
  }
});

router.get('/api/videos/:id', authenticate, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    const video = await db.video.findUnique({
      where: { id },
      include: {
        student: { select: { id: true, email: true, role: true } },
        coach: { select: { id: true, email: true, role: true } },
      },
    });

    if (!video) {
      res.status(404).json({ error: 'Video not found' });
      return;
    }

    if (req.user!.role === 'STUDENT' && video.studentId !== req.user!.userId) {
      res.status(403).json({ error: 'Access denied' });
      return;
    }

    res.json(video);
  } catch (error) {
    logger.error('Get video error', { error: (error as Error).message });
    res.status(500).json({ error: 'Failed to get video' });
  }
});

router.delete('/api/videos/:id', authenticate, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    const video = await db.video.findUnique({
      where: { id },
      include: {
        clips: true,
        annotations: true,
      },
    });

    if (!video) {
      res.status(404).json({ error: 'Video not found' });
      return;
    }

    // Only coach can delete any video, or student can delete their own
    if (req.user!.role === 'STUDENT' && video.studentId !== req.user!.userId) {
      res.status(403).json({ error: 'Access denied' });
      return;
    }

    const UPLOAD_DIR = join(process.cwd(), 'uploads');

    // Delete associated clips and their files
    for (const clip of video.clips) {
      if (clip.outputStorageKey) {
        const clipPath = join(UPLOAD_DIR, clip.outputStorageKey);
        if (existsSync(clipPath)) {
          await unlink(clipPath).catch((err) =>
            logger.warn('Failed to delete clip file', { path: clipPath, error: err.message })
          );
        }
      }
    }

    // Delete the video file
    const videoPath = join(UPLOAD_DIR, video.storageKey);
    if (existsSync(videoPath)) {
      await unlink(videoPath).catch((err) =>
        logger.warn('Failed to delete video file', { path: videoPath, error: err.message })
      );
    }

    // Delete from database (cascade will delete clips and annotations)
    await db.video.delete({ where: { id } });

    logger.info('Video deleted', { videoId: id, userId: req.user!.userId });

    res.json({ message: 'Video deleted successfully' });
  } catch (error) {
    logger.error('Delete video error', { error: (error as Error).message });
    res.status(500).json({ error: 'Failed to delete video' });
  }
});

export default router;
