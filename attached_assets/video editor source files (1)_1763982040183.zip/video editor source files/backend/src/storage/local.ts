import { mkdir, copyFile, access } from 'fs/promises';
import { join, dirname } from 'path';
import { existsSync } from 'fs';
import { logger } from '../utils/logger.js';

const UPLOAD_DIR = join(process.cwd(), 'uploads');

async function ensureDir(dir: string): Promise<void> {
  if (!existsSync(dir)) {
    await mkdir(dir, { recursive: true });
  }
}

export interface PresignedUploadData {
  url: string;
  storageKey: string;
  playbackUrl: string;
}

// Store mapping of uploadId to storageKey
export const uploadIdToStorageKey = new Map<string, string>();

export async function generatePresignedUpload(
  userId: string,
  filename: string,
  _contentType: string
): Promise<PresignedUploadData> {
  await ensureDir(UPLOAD_DIR);

  const timestamp = Date.now();
  const sanitized = filename.replace(/[^a-zA-Z0-9._-]/g, '_');
  const storageKey = `${userId}/${timestamp}_${sanitized}`;

  const uploadId = `${timestamp}_${Math.random().toString(36).substr(2, 9)}`;
  const url = `http://localhost:4000/api/upload/direct/${uploadId}`;

  const playbackUrl = `http://localhost:4000/api/files/uploads/${storageKey}`;

  // Store the mapping so upload-direct can use the correct storage key
  uploadIdToStorageKey.set(uploadId, storageKey);

  logger.info('Generated direct upload URL', { userId, storageKey });

  return { url, storageKey, playbackUrl };
}

export async function uploadFileToLocal(
  localPath: string,
  storageKey: string
): Promise<string> {
  const destPath = join(UPLOAD_DIR, storageKey);
  const destDir = dirname(destPath);

  await ensureDir(destDir);
  await copyFile(localPath, destPath);

  const publicUrl = `http://localhost:4000/api/files/${storageKey}`;
  logger.info('Uploaded file to local storage', { storageKey, publicUrl });

  return publicUrl;
}

export async function getLocalFilePath(storageKey: string): Promise<string> {
  const filePath = join(UPLOAD_DIR, storageKey);

  try {
    await access(filePath);
    return filePath;
  } catch {
    throw new Error(`File not found: ${storageKey}`);
  }
}

export function getPublicUrl(storageKey: string): string {
  return `http://localhost:4000/api/files/uploads/${storageKey}`;
}
