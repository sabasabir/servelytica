import * as localStorage from './local.js';

console.log('📦 Using LOCAL file system storage');

export const generatePresignedUpload = localStorage.generatePresignedUpload;
export const uploadFile = localStorage.uploadFileToLocal;
export const getPublicUrl = localStorage.getPublicUrl;
export const getLocalFilePath = localStorage.getLocalFilePath;
