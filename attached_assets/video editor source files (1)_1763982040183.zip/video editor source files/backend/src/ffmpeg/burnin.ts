import { exec } from 'child_process';
import { promisify } from 'util';
import { tmpdir } from 'os';
import { join } from 'path';
import { existsSync, unlinkSync, createWriteStream } from 'fs';
import { db } from '../db/client.js';
import { uploadFile, getLocalFilePath, getPublicUrl } from '../storage/index.js';
import { logger } from '../utils/logger.js';
import { AnnotationPayload } from '../types/annotations.js';
import https from 'https';
import http from 'http';

const execAsync = promisify(exec);

interface BurninPayload {
  videoId: string;
  annotationId: string;
}

async function downloadFile(url: string, outputPath: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    const file = createWriteStream(outputPath);

    client.get(url, (response) => {
      if (response.statusCode !== 200) {
        reject(new Error(`Failed to download: ${response.statusCode}`));
        return;
      }

      response.pipe(file);

      file.on('finish', () => {
        file.close();
        resolve();
      });

      file.on('error', (err) => {
        unlinkSync(outputPath);
        reject(err);
      });
    }).on('error', (err) => {
      reject(err);
    });
  });
}

export async function burninAnnotations(payload: BurninPayload): Promise<string> {
  const { videoId, annotationId } = payload;

  logger.info('Starting annotation burn-in', { videoId, annotationId });

  const video = await db.video.findUnique({ where: { id: videoId } });
  const annotation = await db.annotation.findUnique({ where: { id: annotationId } });

  if (!video || !annotation) {
    throw new Error('Video or annotation not found');
  }

  const annotationData = annotation.payload as AnnotationPayload;

  const tmpInput = await getLocalFilePath(video.storageKey);
  const tmpOutput = join(tmpdir(), `burnin_output_${videoId}_${Date.now()}.mp4`);

  try {

    let filterComplex = '';

    if (annotationData.comments && annotationData.comments.length > 0) {
      const textFilters = annotationData.comments.map((comment, idx) => {
        const escapedText = comment.text.replace(/'/g, "\\'").replace(/:/g, '\\:');
        const startTime = Math.max(0, comment.at - 2);
        const endTime = comment.at + 3;
        return `drawtext=text='${escapedText}':x=10:y=50+${idx * 30}:fontsize=24:fontcolor=white:box=1:boxcolor=black@0.5:enable='between(t,${startTime},${endTime})'`;
      });

      filterComplex = textFilters.join(',');
    } else {
      filterComplex = 'null';
    }

    const ffmpegCommand = [
      'ffmpeg',
      '-i', `"${tmpInput}"`,
      '-vf', `"${filterComplex}"`,
      '-c:v', 'libx264',
      '-preset', 'medium',
      '-crf', '23',
      '-c:a', 'copy',
      '-movflags', '+faststart',
      '-y',
      `"${tmpOutput}"`
    ].join(' ');

    logger.info('Running FFmpeg burn-in', { command: ffmpegCommand });
    await execAsync(ffmpegCommand, { maxBuffer: 50 * 1024 * 1024 });

    if (!existsSync(tmpOutput)) {
      throw new Error('FFmpeg did not produce burn-in output');
    }

    const outputKey = `rendered/${videoId}_${annotationId}_annotated.mp4`;
    const outputUrl = await uploadFile(tmpOutput, outputKey);

    logger.info('Annotation burn-in completed', { videoId, annotationId, outputUrl });

    return outputUrl;

  } catch (error) {
    logger.error('Annotation burn-in failed', { videoId, annotationId, error: (error as Error).message });
    throw error;
  } finally {
    if (existsSync(tmpOutput)) unlinkSync(tmpOutput);
  }
}
