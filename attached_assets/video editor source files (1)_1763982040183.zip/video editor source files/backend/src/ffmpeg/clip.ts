import { exec } from 'child_process';
import { promisify } from 'util';
import { tmpdir } from 'os';
import { join } from 'path';
import { existsSync, unlinkSync, createWriteStream } from 'fs';
import { db } from '../db/client.js';
import { uploadFile, getLocalFilePath } from '../storage/index.js';
import { logger } from '../utils/logger.js';
import https from 'https';
import http from 'http';

const execAsync = promisify(exec);

interface ClipPayload {
  clipId: string;
}

async function downloadFile(url: string, outputPath: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    const file = createWriteStream(outputPath);

    client.get(url, (response) => {
      if (response.statusCode !== 200) {
        reject(new Error(`Failed to download: ${response.statusCode}`));
        return;
      }

      response.pipe(file);

      file.on('finish', () => {
        file.close();
        resolve();
      });

      file.on('error', (err) => {
        unlinkSync(outputPath);
        reject(err);
      });
    }).on('error', (err) => {
      reject(err);
    });
  });
}

export async function createClip(payload: ClipPayload): Promise<void> {
  const { clipId } = payload;

  logger.info('Starting clip creation', { clipId });

  const clip = await db.clip.findUnique({
    where: { id: clipId },
    include: { video: true },
  });

  if (!clip) {
    throw new Error(`Clip not found: ${clipId}`);
  }

  await db.clip.update({
    where: { id: clipId },
    data: { status: 'RENDERING' },
  });

  const tmpInput = await getLocalFilePath(clip.video.storageKey);
  const tmpOutput = join(tmpdir(), `clip_output_${clipId}_${Date.now()}.mp4`);

  try {

    const duration = clip.endSeconds - clip.startSeconds;

    const ffmpegCommand = [
      'ffmpeg',
      '-ss', clip.startSeconds.toString(),
      '-i', `"${tmpInput}"`,
      '-t', duration.toString(),
      '-c:v', 'libx264',
      '-preset', 'fast',
      '-crf', '23',
      '-c:a', 'aac',
      '-b:a', '128k',
      '-movflags', '+faststart',
      '-y',
      `"${tmpOutput}"`
    ].join(' ');

    logger.info('Running FFmpeg clip extraction', { command: ffmpegCommand });
    await execAsync(ffmpegCommand, { maxBuffer: 50 * 1024 * 1024 });

    if (!existsSync(tmpOutput)) {
      throw new Error('FFmpeg did not produce clip output');
    }

    const outputKey = `clips/${clipId}_${clip.startSeconds}-${clip.endSeconds}.mp4`;
    const outputUrl = await uploadFile(tmpOutput, outputKey);

    await db.clip.update({
      where: { id: clipId },
      data: {
        status: 'READY',
        outputStorageKey: outputKey,
        outputUrl,
      },
    });

    logger.info('Clip creation completed', { clipId, outputUrl });

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logger.error('Clip creation failed', { clipId, error: errorMessage });

    await db.clip.update({
      where: { id: clipId },
      data: {
        status: 'FAILED',
        errorMessage,
      },
    });

    throw error;
  } finally {
    if (existsSync(tmpOutput)) unlinkSync(tmpOutput);
  }
}
