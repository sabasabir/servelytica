import { exec } from 'child_process';
import { promisify } from 'util';
import { tmpdir } from 'os';
import { join } from 'path';
import { existsSync, unlinkSync } from 'fs';
import { db } from '../db/client.js';
import { uploadFile, getLocalFilePath } from '../storage/index.js';
import { logger } from '../utils/logger.js';
import https from 'https';
import http from 'http';
import { createWriteStream } from 'fs';

const execAsync = promisify(exec);

interface NormalizePayload {
  videoId: string;
  inputStorageKey: string;
}

async function downloadFile(url: string, outputPath: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    const file = createWriteStream(outputPath);

    client.get(url, (response) => {
      if (response.statusCode !== 200) {
        reject(new Error(`Failed to download: ${response.statusCode}`));
        return;
      }

      response.pipe(file);

      file.on('finish', () => {
        file.close();
        resolve();
      });

      file.on('error', (err) => {
        unlinkSync(outputPath);
        reject(err);
      });
    }).on('error', (err) => {
      reject(err);
    });
  });
}

async function getVideoDuration(filePath: string): Promise<number> {
  const command = `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${filePath}"`;
  const { stdout } = await execAsync(command);
  return parseFloat(stdout.trim());
}

export async function normalizeVideo(payload: NormalizePayload): Promise<void> {
  const { videoId, inputStorageKey } = payload;

  logger.info('Starting video normalization', { videoId, inputStorageKey });

  await db.video.update({
    where: { id: videoId },
    data: { status: 'PROCESSING' },
  });

  const tmpInput = await getLocalFilePath(inputStorageKey);
  const tmpOutput = join(tmpdir(), `output_${videoId}_${Date.now()}.mp4`);

  try {

    logger.info('Getting video duration');
    const duration = await getVideoDuration(tmpInput);

    const ffmpegCommand = [
      'ffmpeg',
      '-i', `"${tmpInput}"`,
      '-vf', 'scale=-2:720',
      '-c:v', 'libx264',
      '-preset', 'medium',
      '-crf', '23',
      '-r', '30',
      '-c:a', 'aac',
      '-b:a', '128k',
      '-movflags', '+faststart',
      '-y',
      `"${tmpOutput}"`
    ].join(' ');

    logger.info('Running FFmpeg normalization', { command: ffmpegCommand });
    await execAsync(ffmpegCommand, { maxBuffer: 50 * 1024 * 1024 });

    if (!existsSync(tmpOutput)) {
      throw new Error('FFmpeg did not produce output file');
    }

    const outputKey = `processed/${videoId}_normalized.mp4`;
    const playbackUrl = await uploadFile(tmpOutput, outputKey);

    await db.video.update({
      where: { id: videoId },
      data: {
        status: 'READY',
        storageKey: outputKey,
        playbackUrl,
        format: 'mp4',
        durationSeconds: duration,
      },
    });

    logger.info('Video normalization completed', { videoId, playbackUrl });

  } catch (error) {
    logger.error('Video normalization failed', { videoId, error: (error as Error).message });

    await db.video.update({
      where: { id: videoId },
      data: { status: 'FAILED' },
    });

    throw error;
  } finally {
    if (existsSync(tmpOutput)) unlinkSync(tmpOutput);
  }
}
