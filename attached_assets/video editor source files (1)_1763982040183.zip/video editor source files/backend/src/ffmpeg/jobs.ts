import { logger } from '../utils/logger.js';

type JobStatus = 'pending' | 'running' | 'completed' | 'failed';

interface Job {
  id: string;
  type: string;
  status: JobStatus;
  payload: unknown;
  retries: number;
  maxRetries: number;
  error?: string;
  createdAt: Date;
  startedAt?: Date;
  completedAt?: Date;
}

type JobHandler = (payload: any) => Promise<void>;

class JobQueue {
  private jobs: Map<string, Job> = new Map();
  private handlers: Map<string, JobHandler> = new Map();
  private running = false;
  private processingInterval?: NodeJS.Timeout;

  registerHandler(jobType: string, handler: JobHandler): void {
    this.handlers.set(jobType, handler);
    logger.info(`Registered job handler: ${jobType}`);
  }

  enqueue(jobType: string, payload: unknown, maxRetries = 3): string {
    const id = `${jobType}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const job: Job = {
      id,
      type: jobType,
      status: 'pending',
      payload,
      retries: 0,
      maxRetries,
      createdAt: new Date(),
    };

    this.jobs.set(id, job);
    logger.info(`Job enqueued: ${id} (${jobType})`);

    if (!this.running) {
      this.start();
    }

    return id;
  }

  async processJob(job: Job): Promise<void> {
    const handler = this.handlers.get(job.type);
    if (!handler) {
      logger.error(`No handler registered for job type: ${job.type}`);
      job.status = 'failed';
      job.error = 'No handler registered';
      return;
    }

    job.status = 'running';
    job.startedAt = new Date();
    logger.info(`Processing job: ${job.id} (${job.type})`);

    try {
      await handler(job.payload);
      job.status = 'completed';
      job.completedAt = new Date();
      logger.info(`Job completed: ${job.id}`);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger.error(`Job failed: ${job.id}`, { error: errorMessage });

      job.retries++;
      if (job.retries < job.maxRetries) {
        job.status = 'pending';
        const backoffDelay = Math.min(1000 * Math.pow(2, job.retries), 30000);
        logger.info(`Retrying job ${job.id} in ${backoffDelay}ms (attempt ${job.retries + 1}/${job.maxRetries})`);
        setTimeout(() => {
          this.processNextJob();
        }, backoffDelay);
      } else {
        job.status = 'failed';
        job.error = errorMessage;
        job.completedAt = new Date();
        logger.error(`Job exhausted retries: ${job.id}`);
      }
    }
  }

  async processNextJob(): Promise<void> {
    const pendingJob = Array.from(this.jobs.values()).find((j) => j.status === 'pending');

    if (pendingJob) {
      await this.processJob(pendingJob);
    }
  }

  start(): void {
    if (this.running) return;

    this.running = true;
    logger.info('Job queue started');

    this.processingInterval = setInterval(() => {
      this.processNextJob();
    }, 2000);
  }

  stop(): void {
    if (this.processingInterval) {
      clearInterval(this.processingInterval);
      this.processingInterval = undefined;
    }
    this.running = false;
    logger.info('Job queue stopped');
  }

  getJob(id: string): Job | undefined {
    return this.jobs.get(id);
  }

  getJobsByType(type: string): Job[] {
    return Array.from(this.jobs.values()).filter((j) => j.type === type);
  }
}

export const jobQueue = new JobQueue();
