import express from 'express';
import cors from 'cors';
import { env } from './env.js';
import { logger } from './utils/logger.js';
import healthRouter from './routes/health.js';
import uploadRouter from './routes/upload.js';
import uploadDirectRouter from './routes/upload-direct.js';
import filesRouter from './routes/files.js';
import videosRouter from './routes/videos.js';
import annotationsRouter from './routes/annotations.js';
import clipsRouter from './routes/clips.js';
import renderRouter from './routes/render.js';

export function createServer() {
  const app = express();

  app.use(cors());
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true }));

  app.use((req, _res, next) => {
    logger.debug(`${req.method} ${req.path}`);
    next();
  });

  app.use(healthRouter);
  app.use(uploadRouter);
  app.use(uploadDirectRouter);
  app.use(filesRouter);
  app.use(videosRouter);
  app.use(annotationsRouter);
  app.use(clipsRouter);
  app.use(renderRouter);

  app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    logger.error('Unhandled error', { error: err.message, stack: err.stack });
    res.status(500).json({ error: 'Internal server error' });
  });

  return app;
}

export function startServer() {
  const app = createServer();

  const server = app.listen(env.PORT, () => {
    logger.info(`Server started on port ${env.PORT}`);
    logger.info(`Environment: ${env.NODE_ENV}`);
    logger.info(`API URL: http://localhost:${env.PORT}`);
  });

  const shutdown = async () => {
    logger.info('Shutting down gracefully...');
    server.close(() => {
      logger.info('Server closed');
      process.exit(0);
    });

    setTimeout(() => {
      logger.error('Forced shutdown after timeout');
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);

  return server;
}
