import jwt from 'jsonwebtoken';
import { env } from '../env.js';
import { UserRole } from './roles.js';

export interface JWTPayload {
  userId: string;
  email: string;
  role: UserRole;
}

export function signToken(payload: JWTPayload, expiresIn = '30d'): string {
  return jwt.sign(payload, env.JWT_SECRET, { expiresIn });
}

export function verifyToken(token: string): JWTPayload {
  const payload = jwt.verify(token, env.JWT_SECRET) as JWTPayload;
  return payload;
}
