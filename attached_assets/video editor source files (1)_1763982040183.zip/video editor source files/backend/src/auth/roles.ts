export enum Role {
  STUDENT = 'STUDENT',
  COACH = 'COACH',
}

export type UserRole = keyof typeof Role;
