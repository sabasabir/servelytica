import { startServer } from './server.js';
import { jobQueue } from './ffmpeg/jobs.js';
import { normalizeVideo } from './ffmpeg/normalize.js';
import { createClip } from './ffmpeg/clip.js';
import { logger } from './utils/logger.js';

jobQueue.registerHandler('normalize', normalizeVideo);
jobQueue.registerHandler('clip', createClip);

logger.info('Starting Video Review API...');

startServer();
