import { create } from 'zustand';
import { Video, Annotation, Clip, AnnotationItem, AnnotationComment } from '../lib/api';

interface VideoStore {
  selectedVideo: Video | null;
  currentTime: number;
  isPlaying: boolean;
  playbackRate: number;
  annotations: Annotation[];
  clips: Clip[];
  currentAnnotation: {
    name: string;
    items: AnnotationItem[];
    comments: AnnotationComment[];
  } | null;
  selectedTool: 'arrow' | 'circle' | 'freehand' | null;
  strokeColor: string;
  strokeWidth: number;
  annotationDuration: number;

  setSelectedVideo: (video: Video | null) => void;
  setCurrentTime: (time: number) => void;
  setIsPlaying: (playing: boolean) => void;
  setPlaybackRate: (rate: number) => void;
  setAnnotations: (annotations: Annotation[]) => void;
  setClips: (clips: Clip[]) => void;
  setCurrentAnnotation: (annotation: VideoStore['currentAnnotation']) => void;
  addAnnotationItem: (item: AnnotationItem) => void;
  removeLastAnnotationItem: () => void;
  addComment: (comment: AnnotationComment) => void;
  removeComment: (index: number) => void;
  setSelectedTool: (tool: VideoStore['selectedTool']) => void;
  setStrokeColor: (color: string) => void;
  setStrokeWidth: (width: number) => void;
  setAnnotationDuration: (duration: number) => void;
  loadAnnotation: (annotation: Annotation) => void;
  resetAnnotation: () => void;
}

export const useVideoStore = create<VideoStore>((set) => ({
  selectedVideo: null,
  currentTime: 0,
  isPlaying: false,
  playbackRate: 1,
  annotations: [],
  clips: [],
  currentAnnotation: null,
  selectedTool: null,
  strokeColor: '#000000',
  strokeWidth: 3,
  annotationDuration: 2,

  setSelectedVideo: (video) => set({ selectedVideo: video }),
  setCurrentTime: (time) => set({ currentTime: time }),
  setIsPlaying: (playing) => set({ isPlaying: playing }),
  setPlaybackRate: (rate) => set({ playbackRate: rate }),
  setAnnotations: (annotations) => set({ annotations }),
  setClips: (clips) => set({ clips }),
  setCurrentAnnotation: (annotation) => set({ currentAnnotation: annotation }),

  addAnnotationItem: (item) =>
    set((state) => {
      if (!state.currentAnnotation) {
        return {
          currentAnnotation: {
            name: 'Untitled Annotation',
            items: [item],
            comments: [],
          },
        };
      }
      return {
        currentAnnotation: {
          ...state.currentAnnotation,
          items: [...state.currentAnnotation.items, item],
        },
      };
    }),

  removeLastAnnotationItem: () =>
    set((state) => {
      if (!state.currentAnnotation || state.currentAnnotation.items.length === 0) {
        return state;
      }
      const itemsAtCurrentTime = state.currentAnnotation.items.filter(
        (item) => Math.abs(item.at - state.currentTime) < 0.25
      );
      if (itemsAtCurrentTime.length === 0) {
        return state;
      }
      const lastItem = itemsAtCurrentTime[itemsAtCurrentTime.length - 1];
      return {
        currentAnnotation: {
          ...state.currentAnnotation,
          items: state.currentAnnotation.items.filter((item) => item !== lastItem),
        },
      };
    }),

  addComment: (comment) =>
    set((state) => {
      if (!state.currentAnnotation) {
        return {
          currentAnnotation: {
            name: 'Untitled Annotation',
            items: [],
            comments: [comment],
          },
        };
      }
      return {
        currentAnnotation: {
          ...state.currentAnnotation,
          comments: [...state.currentAnnotation.comments, comment],
        },
      };
    }),

  removeComment: (index) =>
    set((state) => {
      if (!state.currentAnnotation || state.currentAnnotation.comments.length === 0) {
        return state;
      }
      return {
        currentAnnotation: {
          ...state.currentAnnotation,
          comments: state.currentAnnotation.comments.filter((_, i) => i !== index),
        },
      };
    }),

  setSelectedTool: (tool) => set({ selectedTool: tool }),
  setStrokeColor: (color) => set({ strokeColor: color }),
  setStrokeWidth: (width) => set({ strokeWidth: width }),
  setAnnotationDuration: (duration) => set({ annotationDuration: duration }),

  loadAnnotation: (annotation) =>
    set({
      currentAnnotation: {
        name: annotation.name,
        items: annotation.payload.items,
        comments: annotation.payload.comments,
      },
    }),

  resetAnnotation: () =>
    set({
      currentAnnotation: {
        name: 'New Annotation',
        items: [],
        comments: [],
      },
    }),
}));
