import { useRef, useState } from 'react';
import { useVideoStore } from '../store/useVideoStore';
import { VideoPlayerRef } from './VideoPlayer';
import { InputModal } from './InputModal';

interface TimelineProps {
  playerRef: React.RefObject<VideoPlayerRef>;
  duration: number;
  mode?: 'coach' | 'student';
}

export function Timeline({ playerRef, duration, mode = 'coach' }: TimelineProps) {
  const { currentTime, addComment, currentAnnotation } = useVideoStore();
  const [isDragging, setIsDragging] = useState(false);
  const [hoverTime, setHoverTime] = useState<number | null>(null);
  const [hoverPosition, setHoverPosition] = useState<number>(0);
  const [isMarkerModalOpen, setIsMarkerModalOpen] = useState(false);
  const timelineRef = useRef<HTMLDivElement>(null);

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!timelineRef.current || !playerRef.current || duration === 0) return;

    const rect = timelineRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percent = Math.max(0, Math.min(1, x / rect.width));
    const time = percent * duration;

    playerRef.current.seekTo(time);
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    setIsDragging(true);
    handleSeek(e);
  };

  const handleMouseUp = (e: React.MouseEvent<HTMLDivElement>) => {
    if (isDragging) {
      handleSeek(e);
    }
    setIsDragging(false);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!timelineRef.current || duration === 0) return;

    const rect = timelineRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percent = Math.max(0, Math.min(1, x / rect.width));
    const time = percent * duration;

    setHoverTime(time);
    setHoverPosition(x);

    if (isDragging) {
      handleSeek(e);
    }
  };

  const handleMouseLeave = () => {
    setIsDragging(false);
    setHoverTime(null);
  };

  const handleAddMarker = () => {
    setIsMarkerModalOpen(true);
  };

  const handleMarkerConfirm = (comment: string) => {
    addComment({ at: currentTime, text: comment });
    setIsMarkerModalOpen(false);
  };

  const handleMarkerCancel = () => {
    setIsMarkerModalOpen(false);
  };

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <>
      <InputModal
        isOpen={isMarkerModalOpen}
        title="Add Marker"
        placeholder="Enter marker comment..."
        onConfirm={handleMarkerConfirm}
        onCancel={handleMarkerCancel}
      />
      <div className="bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 px-3 py-2 border-t-2 border-blue-900/30 shadow-xl">
      <div className="flex items-center gap-3 mb-2">
        <div className="bg-gray-800/50 px-3 py-1 rounded-lg border border-gray-700">
          <span className="text-blue-300 text-sm font-bold font-mono">
            {formatTime(currentTime)}
          </span>
          <span className="text-gray-500 mx-1.5">/</span>
          <span className="text-gray-400 text-sm font-mono">
            {formatTime(duration)}
          </span>
        </div>
        {mode === 'coach' && (
          <button
            onClick={handleAddMarker}
            className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white px-3 py-1 rounded-lg text-xs font-semibold transition-all duration-200 shadow-md hover:shadow-green-500/30 active:scale-95 transform flex items-center gap-1.5"
          >
            <span>📍</span> Add Marker
          </button>
        )}
      </div>
      <div
        ref={timelineRef}
        className="relative h-8 bg-gradient-to-b from-gray-700 to-gray-800 rounded-lg cursor-pointer group shadow-lg border border-gray-700/50 hover:border-blue-500/50 transition-all duration-200"
        onMouseDown={handleMouseDown}
        onMouseUp={handleMouseUp}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
      >
        {/* Progress Bar */}
        <div
          className="absolute top-0 left-0 h-full bg-gradient-to-r from-blue-600 via-blue-500 to-cyan-500 rounded-lg transition-all duration-100 ease-linear shadow-md"
          style={{ width: `${progress}%` }}
        />

        {/* Markers (comments) */}
        {currentAnnotation?.comments.map((comment, idx) => {
          const markerPercent = duration > 0 ? (comment.at / duration) * 100 : 0;
          return (
            <div
              key={idx}
              className="absolute top-0 h-full w-1 bg-green-500 shadow-md z-20 group/marker"
              style={{ left: `${markerPercent}%` }}
              title={comment.text}
            >
              <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-2 h-2 bg-green-400 rounded-full shadow-lg border border-green-600" />
              {/* Tooltip on hover */}
              <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-gray-900 text-white text-xs px-2 py-1 rounded-md shadow-lg whitespace-nowrap border border-green-500/50 opacity-0 group-hover/marker:opacity-100 transition-opacity pointer-events-none max-w-xs overflow-hidden text-ellipsis">
                <div className="font-mono text-blue-300">{formatTime(comment.at)}</div>
                <div className="text-gray-200">{comment.text}</div>
              </div>
            </div>
          );
        })}

        {/* Playhead */}
        <div
          className="absolute top-0 h-full w-0.5 bg-gradient-to-b from-white to-blue-300 shadow-md transition-all duration-100 ease-linear z-10"
          style={{ left: `${progress}%` }}
        >
          <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-3 h-3 bg-white rounded-full shadow-lg border border-blue-500 animate-pulse" />
        </div>

        {/* Hover indicator */}
        {hoverTime !== null && !isDragging && (
          <>
            <div
              className="absolute top-0 h-full w-0.5 bg-yellow-400 opacity-70"
              style={{ left: `${hoverPosition}px` }}
            />
            <div
              className="absolute -top-8 bg-gray-900 text-white text-xs px-2 py-1 rounded-md shadow-lg whitespace-nowrap border border-blue-500/50 font-mono"
              style={{ left: `${hoverPosition}px`, transform: 'translateX(-50%)' }}
            >
              {formatTime(hoverTime)}
            </div>
          </>
        )}
      </div>
      </div>
    </>
  );
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}
