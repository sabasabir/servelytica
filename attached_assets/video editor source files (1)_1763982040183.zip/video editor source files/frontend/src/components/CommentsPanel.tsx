import { useState } from 'react';
import { useVideoStore } from '../store/useVideoStore';
import { VideoPlayerRef } from './VideoPlayer';
import { ConfirmModal } from './ConfirmModal';

interface CommentsPanelProps {
  playerRef: React.RefObject<VideoPlayerRef>;
  mode?: 'coach' | 'student';
}

export function CommentsPanel({ playerRef, mode = 'coach' }: CommentsPanelProps) {
  const { currentAnnotation, currentTime, removeComment } = useVideoStore();
  const [deleteConfirm, setDeleteConfirm] = useState<{ isOpen: boolean; commentIndex: number | null }>({
    isOpen: false,
    commentIndex: null,
  });

  const comments = currentAnnotation?.comments || [];

  const handleSeekToComment = (time: number) => {
    if (playerRef.current) {
      playerRef.current.seekTo(time);
    }
  };

  const handleDeleteClick = (index: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setDeleteConfirm({ isOpen: true, commentIndex: index });
  };

  const handleDeleteConfirm = () => {
    if (deleteConfirm.commentIndex !== null) {
      removeComment(deleteConfirm.commentIndex);
      setDeleteConfirm({ isOpen: false, commentIndex: null });
    }
  };

  const handleDeleteCancel = () => {
    setDeleteConfirm({ isOpen: false, commentIndex: null });
  };

  const sortedComments = [...comments].sort((a, b) => a.at - b.at);

  return (
    <>
      <ConfirmModal
        isOpen={deleteConfirm.isOpen}
        title="Delete Marker"
        message="Are you sure you want to delete this marker?"
        confirmText="Delete"
        cancelText="Cancel"
        onConfirm={handleDeleteConfirm}
        onCancel={handleDeleteCancel}
      />
      <div className="bg-gradient-to-b from-gray-900 to-gray-800 p-5 flex flex-col gap-4 h-full overflow-y-auto">
        <div className="flex items-center justify-between border-b border-gray-700 pb-3">
          <h3 className="text-white text-xl font-bold flex items-center gap-2">
            <span className="text-2xl">💬</span> Markers
          </h3>
          <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-bold">
            {comments.length}
          </span>
        </div>

      {sortedComments.length === 0 ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="text-6xl mb-4 opacity-30">📍</div>
            <p className="text-gray-400 text-sm max-w-xs">
              {mode === 'coach'
                ? 'No markers yet. Click "Add Marker" in the timeline to add markers at specific times.'
                : 'No markers available. Your coach hasn\'t added any markers yet.'}
            </p>
          </div>
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {sortedComments.map((comment, idx) => {
            const isActive = Math.abs(comment.at - currentTime) < 2;
            return (
              <div
                key={idx}
                className={`p-4 rounded-xl cursor-pointer transition-all duration-200 relative group border-2 ${
                  isActive
                    ? 'bg-gradient-to-br from-blue-700 to-blue-800 border-blue-400 shadow-lg shadow-blue-500/30 scale-105'
                    : 'bg-gray-700/50 hover:bg-gray-700 border-gray-600 hover:border-blue-500/50'
                }`}
                onClick={() => handleSeekToComment(comment.at)}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-blue-300 text-sm font-bold font-mono bg-gray-800/50 px-3 py-1 rounded-lg">
                    📍 {formatTime(comment.at)}
                  </span>
                  <div className="flex items-center gap-2">
                    {isActive && (
                      <span className="text-xs text-green-300 bg-green-900/50 px-2 py-1 rounded-full font-semibold animate-pulse">● Live</span>
                    )}
                    {mode === 'coach' && (
                      <button
                        onClick={(e) => handleDeleteClick(idx, e)}
                        className="opacity-0 group-hover:opacity-100 transition-all bg-red-600 hover:bg-red-700 text-white p-2 rounded-lg text-xs shadow-lg active:scale-90"
                        title="Delete marker"
                      >
                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                        </svg>
                      </button>
                    )}
                  </div>
                </div>
                <p className="text-gray-100 text-sm leading-relaxed">{comment.text}</p>
              </div>
            );
          })}
        </div>
      )}
      </div>
    </>
  );
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}
