import { useRef, useState, useEffect } from 'react';
import { VideoPlayer, VideoPlayerRef } from './VideoPlayer';
import { PlaybackControls } from './PlaybackControls';
import { Timeline } from './Timeline';
import { AnnotationCanvas } from './AnnotationCanvas';
import { AnnotationToolbar } from './AnnotationToolbar';
import { ClipCreator } from './ClipCreator';
import { ClipsViewer } from './ClipsViewer';
import { CommentsPanel } from './CommentsPanel';
import { VideoList } from './VideoList';
import { Uploader } from './Uploader';
import { useVideoStore } from '../store/useVideoStore';
import { api, Video } from '../lib/api';

interface VideoReviewSuiteProps {
  mode: 'coach' | 'student';
  userId: string;
}

export default function VideoReviewSuite({ mode, userId }: VideoReviewSuiteProps) {
  const playerRef = useRef<VideoPlayerRef>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [videoDimensions, setVideoDimensions] = useState({ width: 0, height: 0 });
  const [duration, setDuration] = useState(0);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  const {
    selectedVideo,
    setSelectedVideo,
    setAnnotations,
    resetAnnotation,
  } = useVideoStore();

  useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setVideoDimensions({ width: rect.width, height: rect.height });
      }
    };

    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, []);

  const handleVideoSelect = async (video: Video) => {
    if (video.status !== 'READY') {
      alert('Video is not ready yet. Please wait for processing to complete.');
      return;
    }

    setSelectedVideo(video);
    resetAnnotation();

    try {
      const annotations = await api.getVideoAnnotations(video.id);
      setAnnotations(annotations);
    } catch (error) {
      console.error('Failed to load annotations:', error);
    }
  };

  const handleLoadedMetadata = () => {
    if (playerRef.current) {
      setDuration(playerRef.current.getDuration());
    }
  };

  const handleAnnotationSaved = async () => {
    if (selectedVideo) {
      try {
        const annotations = await api.getVideoAnnotations(selectedVideo.id);
        setAnnotations(annotations);
      } catch (error) {
        console.error('Failed to reload annotations:', error);
      }
    }
  };

  return (
    <div className="h-screen w-screen flex flex-col bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 overflow-hidden">
      <header className="bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 border-b-2 border-blue-900/50 px-6 py-4 flex-shrink-0 shadow-xl">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
            Video Review Suite
          </h1>
          <div className="flex items-center gap-4">
            <span className="px-4 py-2 bg-blue-600/20 border border-blue-500/50 rounded-lg text-blue-300 font-semibold text-sm">
              {mode === 'coach' ? '👨‍🏫 Coach View' : '👨‍🎓 Student View'}
            </span>
          </div>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden min-h-0">
        <aside className={`${isSidebarCollapsed ? 'w-0' : 'w-80'} bg-gradient-to-b from-gray-900 to-gray-800 border-r-2 border-blue-900/30 flex flex-col transition-all duration-300 overflow-hidden shadow-2xl`}>
          {!isSidebarCollapsed && (
            <>
              {mode === 'student' && (
                <div className="p-4 border-b border-gray-700">
                  <Uploader userId={userId} onUploadComplete={() => window.location.reload()} />
                </div>
              )}
              <div className="flex-1 overflow-hidden">
                <VideoList
                  onSelectVideo={handleVideoSelect}
                  selectedVideoId={selectedVideo?.id}
                />
              </div>
            </>
          )}
        </aside>

        {/* Sidebar Toggle Button */}
        <button
          onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          className="absolute left-0 top-24 z-20 bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-r-lg shadow-lg transition-all duration-200 hover:scale-110"
          style={{ left: isSidebarCollapsed ? '0' : '320px' }}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            {isSidebarCollapsed ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            )}
          </svg>
        </button>

        <main className="flex-1 flex flex-col overflow-hidden min-w-0">
          {selectedVideo ? (
            <>
              <div className="flex-1 relative bg-black overflow-hidden min-h-0" ref={containerRef}>
                <VideoPlayer
                  ref={playerRef}
                  src={selectedVideo.playbackUrl}
                  onLoadedMetadata={handleLoadedMetadata}
                />
                {mode === 'coach' && videoDimensions.width > 0 && (
                  <AnnotationCanvas
                    width={videoDimensions.width}
                    height={videoDimensions.height}
                    playerRef={playerRef}
                  />
                )}
                {mode === 'student' && videoDimensions.width > 0 && (
                  <div className="absolute top-0 left-0 pointer-events-none">
                    <AnnotationCanvas
                      width={videoDimensions.width}
                      height={videoDimensions.height}
                      playerRef={playerRef}
                    />
                  </div>
                )}
              </div>

              <div className="flex-shrink-0">
                <PlaybackControls playerRef={playerRef} />
                <Timeline playerRef={playerRef} duration={duration} mode={mode} />
              </div>

              {mode === 'coach' && (
                <div className="flex-shrink-0">
                  <AnnotationToolbar
                    videoId={selectedVideo.id}
                    onSaved={handleAnnotationSaved}
                  />
                </div>
              )}
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center bg-gray-900">
              <div className="text-center">
                <div className="mb-6">
                  <svg className="w-32 h-32 mx-auto text-gray-700 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                </div>
                <p className="text-gray-300 text-xl font-semibold mb-3">No video selected</p>
                <p className="text-gray-500 text-sm max-w-md mx-auto">
                  {mode === 'student'
                    ? 'Upload a new video using the upload button or select an existing video from the list on the left'
                    : 'Select a video from the list on the left to begin reviewing and adding annotations'}
                </p>
              </div>
            </div>
          )}
        </main>

        {selectedVideo && (
          <aside className="w-80 bg-gradient-to-b from-gray-900 to-gray-800 border-l-2 border-blue-900/30 flex flex-col shadow-2xl">
            {mode === 'coach' ? (
              <>
                <div className="flex-1 overflow-hidden border-b-2 border-gray-700/50">
                  <CommentsPanel playerRef={playerRef} mode="coach" />
                </div>
                <div className="flex-1 overflow-hidden">
                  <ClipCreator videoId={selectedVideo.id} playerRef={playerRef} />
                </div>
              </>
            ) : (
              <>
                <div className="flex-1 overflow-hidden border-b-2 border-gray-700/50">
                  <CommentsPanel playerRef={playerRef} mode="student" />
                </div>
                <div className="flex-1 overflow-hidden">
                  <ClipsViewer videoId={selectedVideo.id} playerRef={playerRef} />
                </div>
              </>
            )}
          </aside>
        )}
      </div>
    </div>
  );
}
