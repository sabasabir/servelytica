import { useEffect, useState } from 'react';
import { api, Video } from '../lib/api';
import { ConfirmModal } from './ConfirmModal';

interface VideoListProps {
  onSelectVideo: (video: Video) => void;
  selectedVideoId?: string;
}

export function VideoList({ onSelectVideo, selectedVideoId }: VideoListProps) {
  const [videos, setVideos] = useState<Video[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{ isOpen: boolean; videoId: string | null }>({
    isOpen: false,
    videoId: null,
  });

  useEffect(() => {
    loadVideos();
    const interval = setInterval(loadVideos, 10000);
    return () => clearInterval(interval);
  }, []);

  const loadVideos = async () => {
    try {
      const data = await api.getVideos();
      setVideos(data);
      setError(null);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteClick = (videoId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDeleteConfirm({ isOpen: true, videoId });
  };

  const handleDeleteConfirm = async () => {
    if (!deleteConfirm.videoId) return;

    try {
      await api.deleteVideo(deleteConfirm.videoId);
      setDeleteConfirm({ isOpen: false, videoId: null });
      await loadVideos();
    } catch (err) {
      alert(`Failed to delete video: ${(err as Error).message}`);
      setDeleteConfirm({ isOpen: false, videoId: null });
    }
  };

  const handleDeleteCancel = () => {
    setDeleteConfirm({ isOpen: false, videoId: null });
  };

  if (isLoading) {
    return (
      <div className="bg-gradient-to-b from-gray-900 to-gray-800 p-5 h-full flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin text-5xl mb-4">⏳</div>
          <p className="text-gray-300 font-semibold">Loading videos...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-gradient-to-b from-gray-900 to-gray-800 p-5 h-full flex items-center justify-center">
        <div className="text-center">
          <div className="text-5xl mb-4">❌</div>
          <p className="text-red-400 font-semibold">Error: {error}</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <ConfirmModal
        isOpen={deleteConfirm.isOpen}
        title="Delete Video"
        message="Are you sure you want to delete this video? This will also delete all associated clips and annotations."
        confirmText="Delete"
        cancelText="Cancel"
        confirmButtonClass="bg-red-600"
        onConfirm={handleDeleteConfirm}
        onCancel={handleDeleteCancel}
      />
      <div className="bg-gradient-to-b from-gray-900 to-gray-800 p-5 flex flex-col gap-4 h-full overflow-y-auto">
      <div className="flex items-center justify-between border-b border-gray-700 pb-3">
        <h3 className="text-white text-xl font-bold flex items-center gap-2">
          <span className="text-2xl">🎬</span> Videos
          <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-bold">
            {videos.length}
          </span>
        </h3>
        <button
          onClick={loadVideos}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-semibold shadow-lg hover:shadow-blue-500/30 transition-all active:scale-95 flex items-center gap-2"
        >
          🔄 Refresh
        </button>
      </div>

      {videos.length === 0 ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="text-6xl mb-4 opacity-30">📹</div>
            <p className="text-gray-400 text-sm max-w-xs">
              No videos yet. Upload one to get started!
            </p>
          </div>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {videos.map((video) => (
            <div
              key={video.id}
              className={`p-4 rounded-xl transition-all duration-200 relative group border-2 cursor-pointer ${
                selectedVideoId === video.id
                  ? 'bg-gradient-to-br from-blue-700 to-blue-800 border-blue-400 shadow-lg shadow-blue-500/30 scale-105'
                  : 'bg-gray-700/50 hover:bg-gray-700 border-gray-600 hover:border-blue-500/50'
              }`}
            >
              <button
                onClick={() => onSelectVideo(video)}
                className="w-full text-left"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2 flex-1 min-w-0">
                    <span className="text-2xl">🎥</span>
                    <span className="text-gray-100 text-sm font-bold truncate">
                      {video.originalName || `Video ${video.id.slice(0, 8)}`}
                    </span>
                  </div>
                  <span
                    className={`text-xs px-3 py-1 rounded-full font-bold whitespace-nowrap ml-2 ${
                      video.status === 'READY'
                        ? 'bg-green-600 text-white'
                        : video.status === 'FAILED'
                        ? 'bg-red-600 text-white'
                        : video.status === 'PROCESSING'
                        ? 'bg-yellow-600 text-black'
                        : 'bg-gray-600 text-white'
                    }`}
                  >
                    {video.status === 'READY' && '✅ '}
                    {video.status === 'FAILED' && '❌ '}
                    {video.status === 'PROCESSING' && '⏳ '}
                    {video.status}
                  </span>
                </div>
                <div className="flex flex-col gap-1">
                  {video.student && (
                    <p className="text-gray-300 text-xs flex items-center gap-1">
                      <span>👤</span> {video.student.email}
                    </p>
                  )}
                  {video.durationSeconds && (
                    <p className="text-gray-300 text-xs flex items-center gap-1">
                      <span>⏱️</span> {Math.floor(video.durationSeconds)}s
                    </p>
                  )}
                </div>
              </button>
              <button
                onClick={(e) => handleDeleteClick(video.id, e)}
                className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-all bg-red-600 hover:bg-red-700 text-white p-2 rounded-lg text-xs shadow-lg active:scale-90 z-10"
                title="Delete video"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
          ))}
        </div>
      )}
      </div>
    </>
  );
}
