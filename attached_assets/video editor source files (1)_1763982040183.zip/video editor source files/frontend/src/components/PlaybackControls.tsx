import { useEffect } from 'react';
import { useVideoStore } from '../store/useVideoStore';
import { VideoPlayerRef } from './VideoPlayer';

interface PlaybackControlsProps {
  playerRef: React.RefObject<VideoPlayerRef>;
}

export function PlaybackControls({ playerRef }: PlaybackControlsProps) {
  const { isPlaying, playbackRate, setPlaybackRate, setIsPlaying } = useVideoStore();

  const togglePlayPause = () => {
    if (!playerRef.current) return;

    if (isPlaying) {
      playerRef.current.pause();
    } else {
      playerRef.current.play();
    }
  };

  const stepFrame = (direction: 'forward' | 'backward') => {
    if (!playerRef.current) return;

    const frameTime = 1 / 30;
    const currentTime = playerRef.current.getCurrentTime();
    const newTime = direction === 'forward' ? currentTime + frameTime : currentTime - frameTime;
    playerRef.current.seekTo(Math.max(0, newTime));
  };

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        togglePlayPause();
      } else if (e.code === 'BracketLeft') {
        e.preventDefault();
        stepFrame('backward');
      } else if (e.code === 'BracketRight') {
        e.preventDefault();
        stepFrame('forward');
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [isPlaying, playerRef]);

  return (
    <div className="bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 px-3 py-2 flex items-center gap-2 border-t-2 border-blue-900/30 shadow-xl">
      <button
        onClick={togglePlayPause}
        className={`${
          isPlaying ? 'bg-orange-600 hover:bg-orange-700' : 'bg-green-600 hover:bg-green-700'
        } text-white px-4 py-2 rounded-lg font-semibold transition-all duration-200 hover:shadow-lg hover:shadow-blue-500/20 active:scale-95 transform flex items-center gap-1.5`}
      >
        {isPlaying ? (
          <>
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
            <span className="text-sm">Pause</span>
          </>
        ) : (
          <>
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
            </svg>
            <span className="text-sm">Play</span>
          </>
        )}
      </button>

      <div className="flex gap-1 border-l-2 border-gray-700/50 pl-2">
        <button
          onClick={() => stepFrame('backward')}
          className="bg-gray-700 hover:bg-gray-600 text-white px-3 py-2 rounded-lg transition-all duration-200 hover:shadow-md active:scale-95"
          title="Previous frame ([)"
        >
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
          </svg>
        </button>
        <button
          onClick={() => stepFrame('forward')}
          className="bg-gray-700 hover:bg-gray-600 text-white px-3 py-2 rounded-lg transition-all duration-200 hover:shadow-md active:scale-95"
          title="Next frame (])"
        >
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
          </svg>
        </button>
      </div>

      <div className="flex items-center gap-2 border-l-2 border-gray-700/50 pl-2 bg-gray-800/50 rounded-lg px-2 py-1">
        <span className="text-gray-200 text-xs font-semibold">⚡</span>
        {[0.25, 0.5, 1, 2].map((rate) => (
          <button
            key={rate}
            onClick={() => setPlaybackRate(rate)}
            className={`px-2.5 py-1 rounded-md text-xs font-bold transition-all duration-200 ${
              playbackRate === rate
                ? 'bg-blue-600 text-white shadow-md scale-105'
                : 'bg-gray-700 hover:bg-gray-600 text-gray-300 active:scale-95'
            }`}
          >
            {rate}x
          </button>
        ))}
      </div>

      <div className="ml-auto text-gray-400 text-xs border-l-2 border-gray-700/50 pl-2">
        <span className="text-blue-400">⌨️</span> Space: Play | [ / ]: Frame
      </div>
    </div>
  );
}
