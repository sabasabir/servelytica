import { useState } from 'react';
import { api } from '../lib/api';

interface UploaderProps {
  userId: string;
  onUploadComplete?: () => void;
}

export function Uploader({ userId, onUploadComplete }: UploaderProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const validTypes = ['video/mp4', 'video/avi', 'video/quicktime', 'video/x-msvideo'];
      if (!validTypes.includes(file.type)) {
        setError('Invalid file type. Please select MP4, AVI, or MOV.');
        return;
      }

      setSelectedFile(file);
      setError(null);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) return;

    setIsUploading(true);
    setUploadProgress('Getting presigned URL...');
    setError(null);

    try {
      const { url, storageKey, playbackUrl } = await api.getPresignedUpload(
        selectedFile.name,
        selectedFile.type
      );

      setUploadProgress('Uploading to storage...');
      await api.uploadToS3(url, selectedFile);

      setUploadProgress('Registering video...');
      await api.createVideo(userId, storageKey, playbackUrl, selectedFile.name);

      setUploadProgress('Upload complete! Processing...');
      setSelectedFile(null);

      setTimeout(() => {
        setUploadProgress('');
        onUploadComplete?.();
      }, 2000);

    } catch (err) {
      setError((err as Error).message);
      setUploadProgress('');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="bg-gray-800 p-6 rounded-lg">
      <h3 className="text-white text-lg font-semibold mb-4">Upload Video</h3>

      <div className="flex flex-col gap-4">
        <div>
          <input
            type="file"
            accept="video/mp4,video/avi,video/quicktime"
            onChange={handleFileSelect}
            disabled={isUploading}
            className="block w-full text-sm text-gray-300
              file:mr-4 file:py-2 file:px-4
              file:rounded file:border-0
              file:text-sm file:font-semibold
              file:bg-blue-600 file:text-white
              hover:file:bg-blue-700
              file:cursor-pointer cursor-pointer"
          />
          <p className="text-gray-400 text-xs mt-2">
            Supported formats: MP4, AVI, MOV (max recommended: 500MB)
          </p>
        </div>

        {selectedFile && (
          <div className="bg-gray-700 p-3 rounded">
            <p className="text-gray-300 text-sm">
              <strong>Selected:</strong> {selectedFile.name}
            </p>
            <p className="text-gray-400 text-xs">
              Size: {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
            </p>
          </div>
        )}

        {uploadProgress && (
          <div className="bg-blue-900 border border-blue-600 p-3 rounded">
            <p className="text-blue-200 text-sm">{uploadProgress}</p>
          </div>
        )}

        {error && (
          <div className="bg-red-900 border border-red-600 p-3 rounded">
            <p className="text-red-200 text-sm">{error}</p>
          </div>
        )}

        <button
          onClick={handleUpload}
          disabled={!selectedFile || isUploading}
          className="bg-green-600 hover:bg-green-700 disabled:bg-gray-600 text-white px-6 py-3 rounded font-semibold"
        >
          {isUploading ? 'Uploading...' : 'Upload Video'}
        </button>
      </div>
    </div>
  );
}
