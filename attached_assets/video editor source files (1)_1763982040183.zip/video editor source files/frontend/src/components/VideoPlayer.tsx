import { useEffect, useRef, forwardRef, useImperativeHandle, useState } from 'react';
import Hls from 'hls.js';
import { useVideoStore } from '../store/useVideoStore';

export interface VideoPlayerRef {
  play: () => void;
  pause: () => void;
  seekTo: (time: number) => void;
  getCurrentTime: () => number;
  getDuration: () => number;
  isZoomed: () => boolean;
  getZoomTransform: () => { zoom: number; x: number; y: number };
}

interface VideoPlayerProps {
  src: string;
  onTimeUpdate?: (time: number) => void;
  onLoadedMetadata?: () => void;
}

export const VideoPlayer = forwardRef<VideoPlayerRef, VideoPlayerProps>(
  ({ src, onTimeUpdate, onLoadedMetadata }, ref) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const hlsRef = useRef<Hls | null>(null);
    const { setCurrentTime, playbackRate, setIsPlaying, selectedTool } = useVideoStore();
    const [zoom, setZoom] = useState(1);
    const [position, setPosition] = useState({ x: 0, y: 0 });
    const [isDragging, setIsDragging] = useState(false);
    const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

    useImperativeHandle(ref, () => ({
      play: () => {
        videoRef.current?.play();
      },
      pause: () => {
        videoRef.current?.pause();
      },
      seekTo: (time: number) => {
        if (videoRef.current) {
          videoRef.current.currentTime = time;
        }
      },
      getCurrentTime: () => {
        return videoRef.current?.currentTime || 0;
      },
      getDuration: () => {
        return videoRef.current?.duration || 0;
      },
      isZoomed: () => {
        return zoom > 1;
      },
      getZoomTransform: () => {
        return { zoom, x: position.x, y: position.y };
      },
    }));

    useEffect(() => {
      const video = videoRef.current;
      if (!video) return;

      if (src.endsWith('.m3u8')) {
        if (Hls.isSupported()) {
          const hls = new Hls();
          hls.loadSource(src);
          hls.attachMedia(video);
          hlsRef.current = hls;

          return () => {
            hls.destroy();
          };
        } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
          video.src = src;
        }
      } else {
        video.src = src;
      }
    }, [src]);

    useEffect(() => {
      const video = videoRef.current;
      if (!video) return;

      video.playbackRate = playbackRate;
    }, [playbackRate]);

    const handleTimeUpdate = () => {
      const time = videoRef.current?.currentTime || 0;
      setCurrentTime(time);
      onTimeUpdate?.(time);
    };

    const handlePlay = () => {
      setIsPlaying(true);
    };

    const handlePause = () => {
      setIsPlaying(false);
    };

    const handleWheel = (e: React.WheelEvent) => {
      e.preventDefault();
      const delta = e.deltaY > 0 ? -0.1 : 0.1;
      setZoom((prev) => Math.max(1, Math.min(3, prev + delta)));
    };

    const handleMouseDown = (e: React.MouseEvent) => {
      if (zoom > 1 && !selectedTool) {
        setIsDragging(true);
        setDragStart({ x: e.clientX - position.x, y: e.clientY - position.y });
      }
    };

    const handleMouseMove = (e: React.MouseEvent) => {
      if (isDragging && zoom > 1 && !selectedTool && containerRef.current) {
        const container = containerRef.current;
        const rect = container.getBoundingClientRect();

        // Calculate new position
        let newX = e.clientX - dragStart.x;
        let newY = e.clientY - dragStart.y;

        // Calculate maximum allowed pan distance
        const maxPanX = (rect.width * (zoom - 1)) / 2;
        const maxPanY = (rect.height * (zoom - 1)) / 2;

        // Constrain position to prevent moving video out of view
        newX = Math.max(-maxPanX, Math.min(maxPanX, newX));
        newY = Math.max(-maxPanY, Math.min(maxPanY, newY));

        setPosition({ x: newX, y: newY });
      }
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    const handleZoomReset = () => {
      setZoom(1);
      setPosition({ x: 0, y: 0 });
    };

    return (
      <div
        ref={containerRef}
        className="relative w-full h-full bg-black overflow-hidden"
        onWheel={handleWheel}
      >
        <div
          className="w-full h-full"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          style={{
            cursor: selectedTool ? 'crosshair' : zoom > 1 ? (isDragging ? 'grabbing' : 'grab') : 'default',
            pointerEvents: selectedTool ? 'none' : 'auto',
          }}
        >
          <video
            ref={videoRef}
            className="w-full h-full object-contain bg-black"
            style={{
              transform: `scale(${zoom}) translate(${position.x / zoom}px, ${position.y / zoom}px)`,
              transition: isDragging ? 'none' : 'transform 0.1s ease-out',
              pointerEvents: 'none',
            }}
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={onLoadedMetadata}
            onPlay={handlePlay}
            onPause={handlePause}
          />
        </div>
        {zoom > 1 && (
          <div className="absolute top-4 right-4 bg-gray-900 bg-opacity-80 text-white px-3 py-2 rounded-lg flex items-center gap-2 pointer-events-auto z-10">
            <span className="text-sm font-medium">Zoom: {Math.round(zoom * 100)}%</span>
            <button
              onClick={handleZoomReset}
              className="bg-blue-600 hover:bg-blue-700 text-white px-2 py-1 rounded text-xs transition-colors"
            >
              Reset
            </button>
          </div>
        )}
      </div>
    );
  }
);

VideoPlayer.displayName = 'VideoPlayer';
