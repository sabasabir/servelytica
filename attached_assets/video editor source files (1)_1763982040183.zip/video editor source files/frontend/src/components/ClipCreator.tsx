import { useState, useEffect } from 'react';
import { useVideoStore } from '../store/useVideoStore';
import { api, Clip } from '../lib/api';
import { VideoPlayerRef } from './VideoPlayer';
import { ConfirmModal } from './ConfirmModal';

interface ClipCreatorProps {
  videoId: string;
  playerRef: React.RefObject<VideoPlayerRef>;
}

export function ClipCreator({ videoId, playerRef }: ClipCreatorProps) {
  const { currentTime, clips, setClips } = useVideoStore();
  const [startTime, setStartTime] = useState<number | null>(null);
  const [endTime, setEndTime] = useState<number | null>(null);
  const [comment, setComment] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<{ isOpen: boolean; clipId: string | null }>({
    isOpen: false,
    clipId: null,
  });

  useEffect(() => {
    loadClips();
    const interval = setInterval(loadClips, 5000);
    return () => clearInterval(interval);
  }, [videoId]);

  const loadClips = async () => {
    try {
      const data = await api.getVideoClips(videoId);
      setClips(data);
    } catch (error) {
      console.error('Failed to load clips:', error);
    }
  };

  const handleMarkStart = () => {
    setStartTime(currentTime);
  };

  const handleMarkEnd = () => {
    setEndTime(currentTime);
  };

  const handleCreate = async () => {
    if (startTime === null || endTime === null) {
      alert('Please mark both start and end times');
      return;
    }

    if (endTime <= startTime) {
      alert('End time must be after start time');
      return;
    }

    setIsCreating(true);

    try {
      await api.createClip(videoId, startTime, endTime, comment || undefined);
      alert('Clip created and queued for rendering!');
      setStartTime(null);
      setEndTime(null);
      setComment('');
      await loadClips();
    } catch (error) {
      alert(`Failed to create clip: ${(error as Error).message}`);
    } finally {
      setIsCreating(false);
    }
  };

  const handlePlayClip = (clip: Clip) => {
    if (!playerRef.current) return;
    playerRef.current.seekTo(clip.startSeconds);
    playerRef.current.play();

    setTimeout(() => {
      playerRef.current?.pause();
    }, (clip.endSeconds - clip.startSeconds) * 1000);
  };

  const handleDeleteClick = (clipId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDeleteConfirm({ isOpen: true, clipId });
  };

  const handleDeleteConfirm = async () => {
    if (!deleteConfirm.clipId) return;

    try {
      await api.deleteClip(deleteConfirm.clipId);
      setDeleteConfirm({ isOpen: false, clipId: null });
      await loadClips();
    } catch (error) {
      alert(`Failed to delete clip: ${(error as Error).message}`);
      setDeleteConfirm({ isOpen: false, clipId: null });
    }
  };

  const handleDeleteCancel = () => {
    setDeleteConfirm({ isOpen: false, clipId: null });
  };

  return (
    <>
      <ConfirmModal
        isOpen={deleteConfirm.isOpen}
        title="Delete Clip"
        message="Are you sure you want to delete this clip?"
        confirmText="Delete"
        cancelText="Cancel"
        onConfirm={handleDeleteConfirm}
        onCancel={handleDeleteCancel}
      />
      <div className="bg-gradient-to-b from-gray-900 to-gray-800 p-5 flex flex-col gap-5 h-full overflow-y-auto">
        <div className="flex items-center justify-between border-b border-gray-700 pb-3">
          <h3 className="text-white text-xl font-bold flex items-center gap-2">
            <span className="text-2xl">✂️</span> Clip Creator
          </h3>
        </div>

      <div className="flex flex-col gap-3 bg-gray-800/50 rounded-xl p-4 border border-gray-700">
        <div className="flex items-center gap-3">
          <button
            onClick={handleMarkStart}
            className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-4 py-3 rounded-xl flex-1 font-semibold shadow-lg transition-all duration-200 active:scale-95"
          >
            🟢 Start
          </button>
          <span className="text-blue-300 text-sm font-bold font-mono bg-gray-800 px-3 py-2 rounded-lg min-w-[60px] text-center">
            {startTime !== null ? formatTime(startTime) : '--:--'}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleMarkEnd}
            className="bg-gradient-to-r from-orange-600 to-orange-700 hover:from-orange-700 hover:to-orange-800 text-white px-4 py-3 rounded-xl flex-1 font-semibold shadow-lg transition-all duration-200 active:scale-95"
          >
            🔴 End
          </button>
          <span className="text-orange-300 text-sm font-bold font-mono bg-gray-800 px-3 py-2 rounded-lg min-w-[60px] text-center">
            {endTime !== null ? formatTime(endTime) : '--:--'}
          </span>
        </div>

        <input
          type="text"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="💬 Optional comment..."
          className="bg-gray-700 text-gray-200 px-4 py-3 rounded-xl border-2 border-gray-600 focus:border-blue-500 focus:outline-none transition-colors"
        />

        <button
          onClick={handleCreate}
          disabled={isCreating || startTime === null || endTime === null}
          className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 disabled:from-gray-600 disabled:to-gray-700 text-white px-6 py-3 rounded-xl font-bold shadow-xl hover:shadow-green-500/30 transition-all duration-200 active:scale-95 disabled:scale-100"
        >
          {isCreating ? '⏳ Creating...' : '✨ Create Clip'}
        </button>
      </div>

      <div className="border-t-2 border-gray-700/50 pt-4">
        <div className="flex items-center justify-between mb-3">
          <h4 className="text-white text-lg font-bold">Clips</h4>
          <span className="bg-purple-600 text-white px-3 py-1 rounded-full text-sm font-bold">
            {clips.length}
          </span>
        </div>
        <div className="flex flex-col gap-3">
          {clips.length === 0 ? (
            <div className="flex-1 flex items-center justify-center py-8">
              <div className="text-center">
                <div className="text-6xl mb-4 opacity-30">✂️</div>
                <p className="text-gray-400 text-sm">
                  No clips created yet. Mark start and end times to create your first clip!
                </p>
              </div>
            </div>
          ) : (
            clips.map((clip) => (
              <div
                key={clip.id}
                className="bg-gray-700/50 p-4 rounded-xl flex flex-col gap-3 relative group border-2 border-gray-600 hover:border-purple-500/50 transition-all duration-200"
              >
                <div className="flex items-center justify-between">
                  <span className="text-blue-300 text-sm font-bold font-mono bg-gray-800/50 px-3 py-1 rounded-lg">
                    ⏱️ {formatTime(clip.startSeconds)} → {formatTime(clip.endSeconds)}
                  </span>
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-xs px-3 py-1 rounded-full font-bold ${
                        clip.status === 'READY'
                          ? 'bg-green-600 text-white'
                          : clip.status === 'FAILED'
                          ? 'bg-red-600 text-white'
                          : 'bg-yellow-600 text-black'
                      }`}
                    >
                      {clip.status === 'READY' && '✅ '}
                      {clip.status === 'FAILED' && '❌ '}
                      {clip.status === 'PENDING' && '⏳ '}
                      {clip.status}
                    </span>
                    <button
                      onClick={(e) => handleDeleteClick(clip.id, e)}
                      className="opacity-0 group-hover:opacity-100 transition-all bg-red-600 hover:bg-red-700 text-white p-2 rounded-lg text-xs shadow-lg active:scale-90"
                      title="Delete clip"
                    >
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                      </svg>
                    </button>
                  </div>
                </div>
                {clip.comment && (
                  <p className="text-gray-300 text-sm bg-gray-800/30 px-3 py-2 rounded-lg">💬 {clip.comment}</p>
                )}
                <div className="flex gap-2">
                  <button
                    onClick={() => handlePlayClip(clip)}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-semibold shadow-lg transition-all active:scale-95 flex items-center gap-2"
                  >
                    ▶️ Preview
                  </button>
                  {clip.status === 'READY' && clip.outputUrl && (
                    <a
                      href={clip.outputUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-semibold shadow-lg transition-all active:scale-95 flex items-center gap-2"
                    >
                      ⬇️ Download
                    </a>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
      </div>
    </>
  );
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}
