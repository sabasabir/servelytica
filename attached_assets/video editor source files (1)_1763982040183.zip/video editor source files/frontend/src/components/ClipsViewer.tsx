import { useEffect } from 'react';
import { useVideoStore } from '../store/useVideoStore';
import { api, Clip } from '../lib/api';
import { VideoPlayerRef } from './VideoPlayer';

interface ClipsViewerProps {
  videoId: string;
  playerRef: React.RefObject<VideoPlayerRef>;
}

export function ClipsViewer({ videoId, playerRef }: ClipsViewerProps) {
  const { clips, setClips } = useVideoStore();

  useEffect(() => {
    loadClips();
    const interval = setInterval(loadClips, 5000);
    return () => clearInterval(interval);
  }, [videoId]);

  const loadClips = async () => {
    try {
      const data = await api.getVideoClips(videoId);
      setClips(data);
    } catch (error) {
      console.error('Failed to load clips:', error);
    }
  };

  const handlePlayClip = (clip: Clip) => {
    if (!playerRef.current) return;
    playerRef.current.seekTo(clip.startSeconds);
    playerRef.current.play();

    setTimeout(() => {
      playerRef.current?.pause();
    }, (clip.endSeconds - clip.startSeconds) * 1000);
  };

  return (
    <div className="bg-gray-800 p-4 flex flex-col gap-4 h-full overflow-y-auto">
      <h3 className="text-white text-lg font-semibold">Coach Clips</h3>

      {clips.length === 0 ? (
        <div className="text-gray-400 text-sm text-center py-8">
          No clips available yet. Your coach hasn't created any clips for this video.
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {clips.map((clip) => (
            <div
              key={clip.id}
              className="bg-gray-700 p-3 rounded flex flex-col gap-2"
            >
              <div className="flex items-center justify-between">
                <span className="text-gray-300 text-sm">
                  {formatTime(clip.startSeconds)} - {formatTime(clip.endSeconds)}
                </span>
                <span
                  className={`text-xs px-2 py-1 rounded ${
                    clip.status === 'READY'
                      ? 'bg-green-600 text-white'
                      : clip.status === 'FAILED'
                      ? 'bg-red-600 text-white'
                      : 'bg-yellow-600 text-white'
                  }`}
                >
                  {clip.status}
                </span>
              </div>
              {clip.comment && (
                <p className="text-gray-400 text-sm italic">{clip.comment}</p>
              )}
              <div className="flex gap-2">
                <button
                  onClick={() => handlePlayClip(clip)}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm flex-1"
                >
                  Preview in Video
                </button>
                {clip.status === 'READY' && clip.outputUrl && (
                  <a
                    href={clip.outputUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm flex-1 text-center"
                  >
                    Download
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}
