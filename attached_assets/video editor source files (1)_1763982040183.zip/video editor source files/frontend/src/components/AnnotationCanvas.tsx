import { useRef, useState, useEffect } from 'react';
import { Stage, Layer, Arrow, Circle, Line } from 'react-konva';
import { useVideoStore } from '../store/useVideoStore';
import { AnnotationItem } from '../lib/api';
import { VideoPlayerRef } from './VideoPlayer';

interface AnnotationCanvasProps {
  width: number;
  height: number;
  playerRef: React.RefObject<VideoPlayerRef>;
}

export function AnnotationCanvas({ width, height, playerRef }: AnnotationCanvasProps) {
  const {
    currentAnnotation,
    currentTime,
    selectedTool,
    strokeColor,
    strokeWidth,
    annotationDuration,
    addAnnotationItem,
  } = useVideoStore();

  const [zoomTransform, setZoomTransform] = useState({ zoom: 1, x: 0, y: 0 });
  const stageRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Debug log whenever selectedTool changes
  useEffect(() => {
    console.log('[AnnotationCanvas] Tool changed:', { selectedTool, width, height });
  }, [selectedTool, width, height]);

  // Force stage to update when dimensions change
  useEffect(() => {
    if (stageRef.current && width > 0 && height > 0) {
      stageRef.current.width(width);
      stageRef.current.height(height);
      stageRef.current.batchDraw();
    }
  }, [width, height]);

  // Poll for zoom changes
  useEffect(() => {
    const interval = setInterval(() => {
      if (playerRef.current) {
        const transform = playerRef.current.getZoomTransform();
        setZoomTransform(transform);
      }
    }, 16); // ~60fps

    return () => clearInterval(interval);
  }, [playerRef]);

  const [isDrawing, setIsDrawing] = useState(false);
  const [drawStart, setDrawStart] = useState<{ x: number; y: number } | null>(null);
  const [currentPath, setCurrentPath] = useState<number[][]>([]);

  const getTransformedPoint = (stage: any) => {
    const pointerPosition = stage.getPointerPosition();
    // Get the inverse transform to map screen coordinates to canvas coordinates
    const transform = stage.getAbsoluteTransform().copy().invert();
    return transform.point(pointerPosition);
  };

  const handleMouseDown = (e: any) => {
    console.log('[AnnotationCanvas] Mouse down', { selectedTool, currentAnnotation: !!currentAnnotation });
    if (!selectedTool) {
      console.log('[AnnotationCanvas] No tool selected, ignoring click');
      return;
    }

    const stage = e.target.getStage();
    const point = getTransformedPoint(stage);
    console.log('[AnnotationCanvas] Draw start point:', point);

    setIsDrawing(true);
    setDrawStart(point);

    if (selectedTool === 'freehand') {
      setCurrentPath([[point.x, point.y]]);
    }
  };

  const [currentPoint, setCurrentPoint] = useState<{ x: number; y: number } | null>(null);

  const handleMouseMove = (e: any) => {
    if (!isDrawing || !selectedTool) return;

    const stage = e.target.getStage();
    const point = getTransformedPoint(stage);

    setCurrentPoint(point);

    if (selectedTool === 'freehand' && drawStart) {
      setCurrentPath((prev) => [...prev, [point.x, point.y]]);
    }
  };

  const handleMouseUp = (e: any) => {
    console.log('[AnnotationCanvas] Mouse up', { isDrawing, selectedTool, hasDrawStart: !!drawStart });
    if (!isDrawing || !selectedTool || !drawStart) {
      setIsDrawing(false);
      return;
    }

    const stage = e.target.getStage();
    const point = getTransformedPoint(stage);
    console.log('[AnnotationCanvas] Draw end point:', point);

    let item: AnnotationItem | null = null;

    if (selectedTool === 'arrow') {
      item = {
        type: 'arrow',
        at: currentTime,
        props: {
          points: [drawStart.x, drawStart.y, point.x, point.y],
          stroke: strokeColor,
          width: strokeWidth,
        },
      };
    } else if (selectedTool === 'circle') {
      const radius = Math.sqrt(
        Math.pow(point.x - drawStart.x, 2) + Math.pow(point.y - drawStart.y, 2)
      );
      item = {
        type: 'circle',
        at: currentTime,
        props: {
          x: drawStart.x,
          y: drawStart.y,
          r: radius,
          stroke: strokeColor,
          width: strokeWidth,
        },
      };
    } else if (selectedTool === 'freehand') {
      item = {
        type: 'freehand',
        at: currentTime,
        props: {
          path: currentPath,
          stroke: strokeColor,
          width: strokeWidth,
        },
      };
    }

    if (item) {
      console.log('[AnnotationCanvas] Adding annotation item:', item);
      addAnnotationItem(item);
    } else {
      console.log('[AnnotationCanvas] No item created');
    }

    setIsDrawing(false);
    setDrawStart(null);
    setCurrentPath([]);
    setCurrentPoint(null);
  };

  const visibleItems = currentAnnotation?.items.filter(
    (item) => currentTime >= item.at && currentTime <= item.at + annotationDuration
  ) || [];

  return (
    <div
      ref={containerRef}
      className="absolute top-0 left-0 w-full h-full z-10"
      style={{ pointerEvents: selectedTool ? 'auto' : 'none' }}
    >
      <Stage
        ref={stageRef}
        width={width}
        height={height}
        scaleX={zoomTransform.zoom}
        scaleY={zoomTransform.zoom}
        x={(width / 2) * (1 - zoomTransform.zoom) + zoomTransform.x}
        y={(height / 2) * (1 - zoomTransform.zoom) + zoomTransform.y}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        listening={selectedTool !== null}
      >
        <Layer>
          {visibleItems.map((item, idx) => {
            if (item.type === 'arrow') {
              return (
                <Arrow
                  key={idx}
                  points={item.props.points}
                  stroke={item.props.stroke}
                  strokeWidth={item.props.width}
                  fill={item.props.stroke}
                  pointerLength={10}
                  pointerWidth={10}
                />
              );
            } else if (item.type === 'circle') {
              return (
                <Circle
                  key={idx}
                  x={item.props.x}
                  y={item.props.y}
                  radius={item.props.r}
                  stroke={item.props.stroke}
                  strokeWidth={item.props.width}
                />
              );
            } else if (item.type === 'freehand') {
              const flatPoints = item.props.path.flat();
              return (
                <Line
                  key={idx}
                  points={flatPoints}
                  stroke={item.props.stroke}
                  strokeWidth={item.props.width}
                  tension={0.5}
                  lineCap="round"
                  lineJoin="round"
                />
              );
            }
            return null;
          })}

          {isDrawing && drawStart && currentPoint && selectedTool === 'arrow' && (
            <Arrow
              points={[drawStart.x, drawStart.y, currentPoint.x, currentPoint.y]}
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              fill={strokeColor}
              pointerLength={10}
              pointerWidth={10}
            />
          )}

          {isDrawing && drawStart && currentPoint && selectedTool === 'circle' && (
            <Circle
              x={drawStart.x}
              y={drawStart.y}
              radius={Math.sqrt(
                Math.pow(currentPoint.x - drawStart.x, 2) + Math.pow(currentPoint.y - drawStart.y, 2)
              )}
              stroke={strokeColor}
              strokeWidth={strokeWidth}
            />
          )}

          {isDrawing && selectedTool === 'freehand' && currentPath.length > 0 && (
            <Line
              points={currentPath.flat()}
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              tension={0.5}
              lineCap="round"
              lineJoin="round"
            />
          )}
        </Layer>
      </Stage>
    </div>
  );
}
