import { useState } from 'react';
import { useVideoStore } from '../store/useVideoStore';
import { api } from '../lib/api';
import { InputModal } from './InputModal';

interface AnnotationToolbarProps {
  videoId: string;
  onSaved?: () => void;
}

export function AnnotationToolbar({ videoId, onSaved }: AnnotationToolbarProps) {
  const {
    selectedTool,
    setSelectedTool,
    strokeColor,
    setStrokeColor,
    strokeWidth,
    setStrokeWidth,
    annotationDuration,
    setAnnotationDuration,
    removeLastAnnotationItem,
    currentAnnotation,
    resetAnnotation,
    annotations,
    loadAnnotation,
  } = useVideoStore();

  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [selectedAnnotationId, setSelectedAnnotationId] = useState<string>('');
  const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);

  const handleSave = () => {
    if (!currentAnnotation) return;
    setIsSaveModalOpen(true);
  };

  const handleSaveConfirm = async (name: string) => {
    if (!currentAnnotation) return;

    setIsSaving(true);
    setSaveError(null);
    setIsSaveModalOpen(false);

    try {
      await api.createAnnotation(videoId, name, {
        videoId,
        framesPerSecond: 30,
        items: currentAnnotation.items,
        comments: currentAnnotation.comments,
      });

      alert('Annotation saved successfully!');
      onSaved?.();
    } catch (error) {
      setSaveError((error as Error).message);
      alert(`Failed to save: ${(error as Error).message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveCancel = () => {
    setIsSaveModalOpen(false);
  };

  const handleLoad = async () => {
    if (!selectedAnnotationId) return;

    try {
      const annotation = await api.getAnnotation(selectedAnnotationId);
      loadAnnotation(annotation);
      alert('Annotation loaded!');
    } catch (error) {
      alert(`Failed to load: ${(error as Error).message}`);
    }
  };

  return (
    <>
      <InputModal
        isOpen={isSaveModalOpen}
        title="Save Annotation"
        placeholder="Enter annotation name..."
        defaultValue={currentAnnotation?.name || ''}
        onConfirm={handleSaveConfirm}
        onCancel={handleSaveCancel}
      />
      <div className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 px-3 py-2 flex flex-col gap-2 shadow-xl border-t border-gray-700">
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-gray-200 text-xs font-bold tracking-wide">TOOLS</span>
        <div className="flex items-center gap-1 bg-gray-800/50 rounded-lg p-1 border border-gray-700">
          {(['arrow', 'circle', 'freehand'] as const).map((tool) => (
            <button
              key={tool}
              onClick={() => setSelectedTool(selectedTool === tool ? null : tool)}
              className={`px-3 py-1.5 rounded-md capitalize font-medium transition-all duration-200 text-sm ${
                selectedTool === tool
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/50 scale-105'
                  : 'bg-gray-700 hover:bg-gray-600 text-gray-300 hover:text-white'
              }`}
            >
              {tool === 'arrow' && '➜'}
              {tool === 'circle' && '⭕'}
              {tool === 'freehand' && '✏️'}
              <span className="ml-1">{tool}</span>
            </button>
          ))}
        </div>
        <button
          onClick={removeLastAnnotationItem}
          className="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded-md ml-auto font-medium shadow-lg hover:shadow-red-500/50 transition-all duration-200 text-sm"
        >
          ↶ Undo
        </button>
      </div>

      <div className="flex items-center gap-3 flex-wrap bg-gray-800/30 rounded-lg px-3 py-2 border border-gray-700">
        <div className="flex items-center gap-2">
          <label className="text-gray-200 text-xs font-semibold">🎨</label>
          <input
            type="color"
            value={strokeColor}
            onChange={(e) => setStrokeColor(e.target.value)}
            className="w-8 h-8 cursor-pointer rounded border-2 border-gray-600 hover:border-blue-500 transition-all"
          />
        </div>

        <div className="flex items-center gap-2 bg-gray-700/50 rounded-lg px-2 py-1">
          <label className="text-gray-200 text-xs font-semibold">Width:</label>
          <input
            type="range"
            min="1"
            max="10"
            value={strokeWidth}
            onChange={(e) => setStrokeWidth(Number(e.target.value))}
            className="w-20 accent-blue-600"
          />
          <span className="text-blue-400 text-xs font-bold w-5">{strokeWidth}</span>
        </div>

        <div className="flex items-center gap-2 bg-gray-700/50 rounded-lg px-2 py-1">
          <label className="text-gray-200 text-xs font-semibold">Duration:</label>
          <input
            type="range"
            min="0.5"
            max="10"
            step="0.5"
            value={annotationDuration}
            onChange={(e) => setAnnotationDuration(Number(e.target.value))}
            className="w-20 accent-green-600"
          />
          <span className="text-green-400 text-xs font-bold w-8">{annotationDuration.toFixed(1)}s</span>
        </div>
      </div>

      <div className="flex items-center gap-2 flex-wrap bg-gray-800/30 rounded-lg px-3 py-2 border border-gray-700">
        <button
          onClick={handleSave}
          disabled={isSaving || !currentAnnotation}
          className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 disabled:from-gray-600 disabled:to-gray-700 text-white px-3 py-1.5 rounded-lg font-semibold shadow-lg hover:shadow-green-500/30 transition-all duration-200 active:scale-95 disabled:scale-100 flex items-center gap-1 text-sm"
        >
          {isSaving ? (
            <><span className="animate-spin">⏳</span> Saving...</>
          ) : (
            <><span>💾</span> Save</>
          )}
        </button>

        <button
          onClick={resetAnnotation}
          className="bg-gradient-to-r from-yellow-600 to-yellow-700 hover:from-yellow-700 hover:to-yellow-800 text-white px-3 py-1.5 rounded-lg font-semibold shadow-lg hover:shadow-yellow-500/30 transition-all duration-200 active:scale-95 flex items-center gap-1 text-sm"
        >
          <span>✨</span> New
        </button>

        <select
          value={selectedAnnotationId}
          onChange={(e) => setSelectedAnnotationId(e.target.value)}
          className="bg-gray-700 text-gray-200 px-3 py-1.5 rounded-lg border-2 border-gray-600 focus:border-blue-500 focus:outline-none transition-colors font-medium text-sm"
        >
          <option value="">📂 Select...</option>
          {annotations.map((ann) => (
            <option key={ann.id} value={ann.id}>
              {ann.name}
            </option>
          ))}
        </select>

        <button
          onClick={handleLoad}
          disabled={!selectedAnnotationId}
          className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 disabled:from-gray-600 disabled:to-gray-700 text-white px-3 py-1.5 rounded-lg font-semibold shadow-lg hover:shadow-blue-500/30 transition-all duration-200 active:scale-95 disabled:scale-100 flex items-center gap-1 text-sm"
        >
          <span>📥</span> Load
        </button>
      </div>

      {saveError && (
        <div className="bg-red-900/50 border border-red-500 text-red-200 px-3 py-2 rounded-lg text-xs flex items-center gap-2">
          <span>❌</span> {saveError}
        </div>
      )}
      </div>
    </>
  );
}
