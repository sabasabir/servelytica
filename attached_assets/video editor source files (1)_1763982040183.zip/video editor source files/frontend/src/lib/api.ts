import { getToken } from './auth';

const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:4000';

interface RequestOptions extends RequestInit {
  auth?: boolean;
}

async function request<T>(endpoint: string, options: RequestOptions = {}): Promise<T> {
  const { auth = true, ...fetchOptions } = options;

  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...fetchOptions.headers,
  };

  if (auth) {
    const token = getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
  }

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...fetchOptions,
    headers,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(error.error || `HTTP ${response.status}`);
  }

  return response.json();
}

export interface Video {
  id: string;
  studentId: string;
  coachId: string | null;
  storageKey: string;
  playbackUrl: string;
  originalName: string | null;
  durationSeconds: number | null;
  format: string | null;
  status: 'UPLOADED' | 'PROCESSING' | 'READY' | 'FAILED';
  createdAt: string;
  updatedAt: string;
  student?: { id: string; email: string; role: string };
  coach?: { id: string; email: string; role: string };
}

export interface AnnotationItem {
  type: 'arrow' | 'circle' | 'freehand';
  at: number;
  props: any;
}

export interface AnnotationComment {
  at: number;
  text: string;
}

export interface AnnotationPayload {
  videoId: string;
  framesPerSecond: number;
  items: AnnotationItem[];
  comments: AnnotationComment[];
}

export interface Annotation {
  id: string;
  videoId: string;
  coachId: string;
  name: string;
  payload: AnnotationPayload;
  createdAt: string;
  updatedAt: string;
  coach?: { id: string; email: string; role: string };
}

export interface Clip {
  id: string;
  videoId: string;
  coachId: string;
  startSeconds: number;
  endSeconds: number;
  comment: string | null;
  outputStorageKey: string | null;
  outputUrl: string | null;
  status: 'QUEUED' | 'RENDERING' | 'READY' | 'FAILED';
  errorMessage: string | null;
  createdAt: string;
  updatedAt: string;
  coach?: { id: string; email: string; role: string };
}

export const api = {
  async getPresignedUpload(filename: string, contentType: string) {
    return request<{ url: string; storageKey: string; playbackUrl: string }>(
      '/api/upload/presign',
      {
        method: 'POST',
        body: JSON.stringify({ filename, contentType }),
      }
    );
  },

  async uploadToS3(url: string, file: File): Promise<void> {
    // Check if it's a local upload (contains /api/upload/direct/)
    const isLocalUpload = url.includes('/api/upload/direct/');

    const headers: HeadersInit = {
      'Content-Type': file.type,
    };

    // Add authorization header for local uploads
    if (isLocalUpload) {
      const token = getToken();
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
    }

    const response = await fetch(url, {
      method: 'PUT',
      body: file,
      headers,
    });

    if (!response.ok) {
      throw new Error(`Upload failed: ${response.status}`);
    }
  },

  async createVideo(studentId: string, storageKey: string, playbackUrl: string, originalName?: string) {
    return request<Video>('/api/videos', {
      method: 'POST',
      body: JSON.stringify({ studentId, storageKey, playbackUrl, originalName }),
    });
  },

  async getVideos() {
    return request<Video[]>('/api/videos');
  },

  async getVideo(id: string) {
    return request<Video>(`/api/videos/${id}`);
  },

  async deleteVideo(id: string) {
    return request<{ message: string }>(`/api/videos/${id}`, {
      method: 'DELETE',
    });
  },

  async createAnnotation(videoId: string, name: string, payload: AnnotationPayload) {
    return request<Annotation>('/api/annotations', {
      method: 'POST',
      body: JSON.stringify({ videoId, name, payload }),
    });
  },

  async getVideoAnnotations(videoId: string) {
    return request<Annotation[]>(`/api/videos/${videoId}/annotations`);
  },

  async getAnnotation(id: string) {
    return request<Annotation>(`/api/annotations/${id}`);
  },

  async createClip(videoId: string, startSeconds: number, endSeconds: number, comment?: string) {
    return request<Clip>('/api/clips', {
      method: 'POST',
      body: JSON.stringify({ videoId, startSeconds, endSeconds, comment }),
    });
  },

  async getVideoClips(videoId: string) {
    return request<Clip[]>(`/api/videos/${videoId}/clips`);
  },

  async getClip(id: string) {
    return request<Clip>(`/api/clips/${id}`);
  },

  async deleteClip(id: string) {
    return request<{ message: string }>(`/api/clips/${id}`, {
      method: 'DELETE',
    });
  },
};
