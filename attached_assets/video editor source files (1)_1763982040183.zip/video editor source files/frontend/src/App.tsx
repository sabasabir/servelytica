import { useState } from 'react';
import VideoReviewSuite from './components/VideoReviewSuite';
import { setToken } from './lib/auth';

export default function App() {
  const [mode, setMode] = useState<'coach' | 'student' | null>(null);
  const [userId, setUserId] = useState<string>('');

  const handleSelectRole = (role: 'coach' | 'student', token: string, id: string) => {
    setToken(token);
    setMode(role);
    setUserId(id);
  };

  if (!mode) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center p-8">
        <div className="max-w-2xl w-full bg-gray-800 rounded-lg p-8">
          <h1 className="text-3xl font-bold text-white mb-6 text-center">
            Video Review Suite Demo
          </h1>

          <div className="mb-8 bg-blue-900 border border-blue-600 p-4 rounded">
            <h2 className="text-blue-200 font-semibold mb-2">Setup Instructions:</h2>
            <ol className="text-blue-200 text-sm space-y-1 list-decimal list-inside">
              <li>Start the backend: <code className="bg-blue-950 px-2 py-1 rounded">pnpm --filter backend dev</code></li>
              <li>Run database seed to get JWT tokens</li>
              <li>Copy the tokens from backend logs</li>
              <li>Paste them below to authenticate</li>
            </ol>
          </div>

          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-semibold text-white mb-4">Student View</h2>
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Student JWT Token"
                  className="w-full bg-gray-700 text-gray-300 px-4 py-3 rounded"
                  onChange={(e) => {
                    if (e.target.value.length > 10) {
                      const decoded = JSON.parse(atob(e.target.value.split('.')[1]));
                      setUserId(decoded.userId);
                    }
                  }}
                  id="student-token"
                />
                <button
                  onClick={() => {
                    const input = document.getElementById('student-token') as HTMLInputElement;
                    if (input.value) {
                      const decoded = JSON.parse(atob(input.value.split('.')[1]));
                      handleSelectRole('student', input.value, decoded.userId);
                    }
                  }}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded font-semibold"
                >
                  Enter as Student
                </button>
              </div>
            </div>

            <div className="border-t border-gray-700 pt-6">
              <h2 className="text-xl font-semibold text-white mb-4">Coach View</h2>
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Coach JWT Token"
                  className="w-full bg-gray-700 text-gray-300 px-4 py-3 rounded"
                  id="coach-token"
                />
                <button
                  onClick={() => {
                    const input = document.getElementById('coach-token') as HTMLInputElement;
                    if (input.value) {
                      const decoded = JSON.parse(atob(input.value.split('.')[1]));
                      handleSelectRole('coach', input.value, decoded.userId);
                    }
                  }}
                  className="w-full bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded font-semibold"
                >
                  Enter as Coach
                </button>
              </div>
            </div>
          </div>

          <div className="mt-8 text-gray-400 text-sm text-center">
            <p>This is a demo interface. In production, authentication would be handled by your existing app.</p>
          </div>
        </div>
      </div>
    );
  }

  return <VideoReviewSuite mode={mode} userId={userId} />;
}
